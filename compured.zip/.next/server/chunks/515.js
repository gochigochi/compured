"use strict";exports.id=515,exports.ids=[515],exports.modules={3618:(e,t,i)=>{i.d(t,{Z:()=>r});var o=i(997),a=i(7518),n=i.n(a);let l=n().button`
    background-color: ${({dis:e})=>e?"var(--dark-blue)":"var(--blue)"};
    border-radius: 25px;
    padding: var(--button-padding);
    color: #fff;
    cursor: ${({dis:e})=>e?"default":"pointer"};
    transition: all .2s;

    &:hover {
        ${({dis:e})=>!e&&"opacity: .8;"}
    }
`,r=({children:e,onClick:t=()=>{},disabled:i=!1})=>o.jsx(l,{onClick:t,disabled:i,dis:i,children:e})},1549:(e,t,i)=>{i.d(t,{C:()=>o,P:()=>a});let o={initial:{scale:.85,y:15},animate:{scale:1,y:0,transition:{delay:.05,ease:[.79,.33,.14,.53]}}},a={initial:{y:-15,opacity:0},animate:{y:0,opacity:1,transition:{delay:.05,ease:[.79,.33,.14,.53]}}}},1766:(e,t,i)=>{i.a(e,async(e,o)=>{try{i.d(t,{Dx:()=>c,W2:()=>s,Zb:()=>d,xh:()=>p,xv:()=>Text});var a=i(7518),n=i.n(a),l=i(6197),r=e([l]);l=(r.then?(await r)():r)[0];let s=n().section`
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    padding: 45px 0;

    @media all and (max-width: 750px) {
        justify-content: center;
        padding: 0;
    }
`,d=n()(l.motion.div)`
    position: relative;
    width: 32%;
    height: 500px;
    margin-bottom: 20px;
    border-radius: 12px;
    overflow: hidden;
    padding: 25px;
    display: flex;
    flex-direction: column;
    justify-content: flex-end;
    gap: 25px;

    &:nth-child(2), &:nth-child(5) {
        position: relative;
        top: 55px;
    }

    @media all and (max-width: 1024px) {
        width: 48%;

        &:nth-child(5) {
            top: 0;
        }

        &:nth-child(even) {
            top: 55px;
        }
    }

    @media all and (max-width: 750px) {
        width: 100%;
        height: 400px 

        &:nth-child(2) { 
            top: 0;
        }

        &:nth-child(even) {
            top: 0;
        }
    }
`,c=n().h3`
    color: #fff;
    font-size: 2.3rem;
`,Text=n().p`
    color: #fff;
    font-size: 1.2rem;
    line-height: 1.4;
    border-left: 5px solid var(--blue);
    padding-left: 10px;
`,p=n().span`
    color: #fff;
    margin-left: 8px;
`;o()}catch(e){o(e)}})},4515:(e,t,i)=>{i.a(e,async(e,o)=>{try{i.r(t),i.d(t,{default:()=>m});var a=i(997),n=i(5675),l=i.n(n),r=i(1664),s=i.n(r),d=i(3618),c=i(6739),p=i(1549),x=i(1766),h=e([x]);x=(h.then?(await h)():h)[0];let u=[{title:"Servicio T\xe9cnico",text:"Sabemos la importancia de la tecnolog\xeda en la vida diaria de todas las personas. Asesoramos y solucionamos lo que los clientes necesiten, en materia de servicio t\xe9cnico.",isContact:!0,bg:"https://drive.google.com/uc?export=view&id=15v7PBO5yrAglF0t16xqESutYQWnWWoFJ"},{title:"Dom\xf3tica",text:"Transforma tu hogar en un espacio inteligente, controlando luces, seguridad, climatizaci\xf3n y m\xe1s. Descubre el futuro de tu hogar hoy mismo",isLink:!0,url:"#",bg:"https://drive.google.com/uc?export=view&id=1RWrmnIYXnjlELzKr-D1mtbhAFOugZtc0"},{title:"C\xe1maras de seguridad",text:"Protege lo que m\xe1s quieres con nuestras c\xe1maras de seguridad. Mant\xe9n tu hogar o negocio seguro las 24 horas del d\xeda. Contamos con instalaci\xf3n profesional y equipos de alta calidad.",isLink:!0,url:"#",bg:"https://drive.google.com/uc?export=view&id=1mKJ2PtGtUsBd1w7yPJv6szaLBImfQxpD"},{title:"Sustentabilidad",text:"Nuestro compromiso con el mundo es parte fundamental del prop\xf3sito de la empresa. Conoce nuestro impacto ambiental y social.",isContact:!0,bg:"https://drive.google.com/uc?export=view&id=16ZAEQQR6OXiB_kRfL2T-wQA_DPr1393j"},{title:"Franquicias",text:"Tecnolog\xeda y Sustentabilidad son los componentes con mayor crecimiento a nivel mundial. CompuRed cuenta con ambos. \xbfQuer\xe9s conocer nuestro plan de expansi\xf3n?",isLink:!0,url:"#",bg:"https://drive.google.com/uc?export=view&id=1T2RFBAJVUhqfZBaRg04tWWRl5uu1Oq5T"},{title:"Ecommerce",text:"Conoc\xe9 nuestros productos en nuestro comercio online",isLink:!0,url:"#",bg:"https://drive.google.com/uc?export=view&id=1T2RFBAJVUhqfZBaRg04tWWRl5uu1Oq5T"}],m=()=>a.jsx(x.W2,{children:u.map(e=>(0,a.jsxs)(x.Zb,{variants:p.C,initial:"initial",whileInView:"animate",children:[a.jsx(l(),{src:e.bg,alt:"",fill:!0,style:{objectFit:"cover",zIndex:"-1"}}),a.jsx(x.Dx,{children:e.title}),a.jsx(x.xv,{children:e.text}),a.jsx("div",{children:a.jsx(d.Z,{children:e.isLink?(0,a.jsxs)(s(),{href:e.url,style:{display:"flex",alignItems:"center"},children:[a.jsx(c.xN,{width:"15px",height:"15px",color:"#fff"}),a.jsx(x.xh,{children:"Ver m\xe1s"})]}):(0,a.jsxs)("a",{href:"https://api.whatsapp.com/send?phone=5492944154964&text=Hola",rel:"noopene noreferrer",target:"_blank",style:{display:"flex",alignItems:"center"},children:[a.jsx(c.yN,{width:"12px",height:"12px",color:"#fff"}),a.jsx(x.xh,{children:"Contactanos"})]})})})]}))});o()}catch(e){o(e)}})}};