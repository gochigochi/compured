exports.id=158,exports.ids=[158],exports.modules={1323:(e,r)=>{"use strict";Object.defineProperty(r,"l",{enumerable:!0,get:function(){return function e(r,t){return t in r?r[t]:"then"in r&&"function"==typeof r.then?r.then(r=>e(r,t)):"function"==typeof r&&"default"===t?r:void 0}}})},6537:(e,r,t)=>{"use strict";t.d(r,{Z:()=>a,u:()=>s});var n=t(997),i=t(6689);let o=(0,i.createContext)(),s=()=>(0,i.useContext)(o),a=({children:e})=>{let[r,t]=(0,i.useState)();return n.jsx(o.Provider,{value:{categories:r,setCategories:t},children:e})}},5401:(e,r,t)=>{"use strict";t.r(r),t.d(r,{default:()=>O});var n=t(997),i=t(2435),o=t.n(i);t(6764);var s=t(6689);let a=()=>(0,n.jsxs)("svg",{xmlns:"http://www.w3.org/2000/svg",width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[n.jsx("circle",{cx:"11",cy:"11",r:"8"}),n.jsx("line",{x1:"21",y1:"21",x2:"16.65",y2:"16.65"})]}),d=()=>(0,n.jsxs)("svg",{xmlns:"http://www.w3.org/2000/svg",width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[n.jsx("line",{x1:"5",y1:"12",x2:"19",y2:"12"}),n.jsx("polyline",{points:"12 5 19 12 12 19"})]}),l=()=>(0,n.jsxs)("svg",{xmlns:"http://www.w3.org/2000/svg",width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[n.jsx("line",{x1:"19",y1:"12",x2:"5",y2:"12"}),n.jsx("polyline",{points:"12 19 5 12 12 5"})]});var c=t(7518),p=t.n(c);let u=p().form` 
    display: flex;
    align-items: center;
`,x=p().input`
    width: 100%;
    height: 35px;
    border-radius: 500px 0 0 500px;
    border: 1px solid #cfd7d9;
    padding: 5px 20px;
    font-size: 1rem;
`,h=p().button`
    cursor: pointer;
    border-radius: 0 500px 500px 0;
    border: 1px solid #cfd7d9;
    border-left: none;
    height: 35px;
    padding: 5px;
    width: 65px;
    display: grid;
    place-items: center;

    svg {
        font-size: 1.4rem;
    }
`,g=async e=>{let r=await fetch("https://api-beta.saasargentina.com/v1/productos?callback=productoscallback&busqueda=Auriculares&datosextras=&desde=0&cantidad=100&mostrarimagenes=1&idrubro=0&orden=nombre");console.log(r);let t=await r.json();console.log(t)},m=()=>{let e=(0,s.useRef)();return(0,n.jsxs)(u,{onSubmit:r=>{if(r.preventDefault(),e.current&&e?.current?.length!==0){let r=e.current.toLowerCase().trim().normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/[^a-zA-Z0-9 ]/g,"").replace(/\s+/g,"-");g(r)}},children:[n.jsx(x,{type:"text",name:"term",onChange:r=>e.current=r.target.value}),n.jsx(h,{type:"submit",children:n.jsx(a,{})})]})};var f=t(1163),b=t(6537);let j=e=>e.toLowerCase().replace(/[^a-z0-9 -]/g,"").replace(/\s+/g,"-").replace(/-+/g,"-").trim();var w=t(1664),y=t.n(w);let v=p().div`
    position: relative;
`,k=p().button`
    cursor: pointer;
`,P=p().div`
    position: absolute;
    top: 50px;
    padding: 25px;
    background-color: #fff;
    display: grid;
    width: 100vw;
    max-width: 400px;
    max-height: 80vh;
    overflow-y: scroll;
    box-shadow: var(--light-shadow);
    border-radius: 12px;
`,E=p().button`
    padding: 25px;
    cursor: pointer;
    border-radius: 8px;
    display: flex;
    align-items: center;
    position: relative;

    &:hover {
        background-color: #ededed;

        i {
            right: 25px;
            opacity: 1;
        }
    }
`,C=p().i`
    position: absolute;
    right: 30px;
    transition: all .2s ease-in-out;
    opacity: 0;

    svg {
        font-size: 5px;
    }
`,S=p().div`
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0 25px 25px 20px;
`,A=p().button`
    padding: 25px;
    cursor: pointer;
    border-radius: 8px;
    display: flex;
    align-items: center;
    position: relative;

    &:hover {
        background-color: #ededed;

        i {
            right: 25px;
            opacity: 1;
        }
    }
`,$=p().button`
    cursor: pointer;
`,L=p().button`
    width: 20px;
    height: auto;
    display: grid;
    place-items: center;
    cursor: pointer;

    svg {
        pointer-events: none;
    }
`,_=({children:e})=>{let r=(0,f.useRouter)(),{categories:t}=(0,b.u)(),[i,o]=(0,s.useState)(!1),[a,c]=(0,s.useState)({name:"",id:"",items:[]});(0,s.useEffect)(()=>{let e=e=>{"container"!==e.target.id&&"flyout-btn"!==e.target.id&&(o(!i),c([]))};return i&&window.addEventListener("click",e),i||window.removeEventListener("click",e),()=>window.removeEventListener("click",e)},[i]);let p=(e,t)=>{let n=j(e);r.push(`/productos/${t}`,`/productos/id=${t}&${n}`)};return(0,n.jsxs)(v,{children:[n.jsx(k,{id:"flyout-btn",onClick:()=>o(!i),children:e}),i?n.jsx(P,{id:"container",children:a?.items?.length>0?n.jsx(()=>(0,n.jsxs)(n.Fragment,{children:[(0,n.jsxs)(S,{children:[n.jsx(L,{id:"flyout-btn",onClick:()=>c({name:"",id:"",items:[]}),children:n.jsx(l,{})}),n.jsx($,{onClick:()=>p(a.name,a.id),children:"Ver todo"})]}),a?.items.map(e=>n.jsxs(A,{onClick:()=>p(e.nombre,e.idrubro),id:"flyout-btn",children:[e.nombre,n.jsx(C,{children:n.jsx(d,{})})]},e.idrubro))]}),{}):n.jsx(()=>n.jsx(n.Fragment,{children:t?.map(e=>n.jsxs(E,{onClick:()=>c({name:e.parent.nombre,id:e.parent.idrubro,items:e.children}),id:"flyout-btn",children:[e.parent.nombre,n.jsx(C,{children:n.jsx(d,{})})]},e.parent.idrubro))}),{})}):null]})},q=p().nav`
    position: relative;
    top: 2px;
    margin-left: 100px;
    display: flex;
    gap: 25px;
    align-items: center;
`,z=p()(y())`
    font-weight: 500;
`,I=()=>(0,n.jsxs)(q,{children:[n.jsx(_,{children:"Categor\xedas"}),n.jsx(z,{href:"/",children:"Servicios"}),n.jsx(z,{href:"/",children:"Contacto"})]});var N=t(5675),R=t.n(N);let B=p().header`
    position: relative;
    box-shadow: 0px 5px 11px 0px rgba(25, 141, 179, 0.1);
    z-index: 800;
`,G=p().div`
    max-width: 1500px;
    margin: 0 auto;
    padding: 0 12px;
    display: flex;
    justify-content: space-between;
    display: grid;
    grid-template-columns: minmax(100px, 150px) 1fr minmax(250px, 500px);
`,W=p()(y())`
    position: relative;
    height: 70px;
`,D=p()(R())`
    object-fit: contain;
`,F=()=>n.jsx(B,{children:(0,n.jsxs)(G,{children:[n.jsx(W,{href:"/",children:n.jsx(D,{src:"/assets/logo.png",alt:"logo compured",fill:!0,priority:!0})}),n.jsx(I,{}),n.jsx(m,{})]})}),T=({children:e})=>(0,n.jsxs)(n.Fragment,{children:[n.jsx(F,{}),n.jsx("main",{children:e})]});function O({Component:e,pageProps:r}){return n.jsx(b.Z,{children:n.jsx(T,{className:o().className,children:n.jsx(e,{...r})})})}},4003:(e,r,t)=>{"use strict";t.r(r),t.d(r,{default:()=>a});var n=t(997),i=t(6859),o=t.n(i),s=t(7518);class a extends o(){static async getInitialProps(e){let r=new s.ServerStyleSheet,t=e.renderPage;try{e.renderPage=()=>t({enhanceApp:e=>t=>r.collectStyles(n.jsx(e,{...t}))});let i=await o().getInitialProps(e);return{...i,styles:(0,n.jsxs)(n.Fragment,{children:[i.styles,r.getStyleElement()]})}}finally{r.seal()}}render(){return(0,n.jsxs)(i.Html,{lang:"en",children:[n.jsx(i.Head,{}),(0,n.jsxs)("body",{children:[n.jsx(i.Main,{}),n.jsx(i.NextScript,{})]})]})}}},5861:(e,r,t)=>{"use strict";async function n(e){let r=[1,2],t=[];for(let n=0;n<r.length;n++)t.push(await i(r[n],e));let n=new Set(t.map(e=>e.idproducto));return t=[...n].map(e=>t.find(r=>r.idproducto===e))}async function i(e,r){try{let t=await fetch(`https://api-beta.saasargentina.com/v1/productos?busqueda=&datosextras=&desde=0&cantidad=100&iddeposito=${e}&mostrarimagenes=1&idrubro=${r}&orden=nombre&iue=PuaNYqpDhRBJ7K80I8WC&S=epqr6c893g5khekkir9s0l6k6n&_=1700488253028`);if(!t.ok)throw Error(`Error en la solicitud: ${t.statusText}`);let n=await t.json();return n.resultados}catch(e){console.error(`Error en cargarProductos: ${e.message}`)}}async function o(){try{let e=await fetch("https://api-beta.saasargentina.com/v1/rubros?idrubro=0&desde=0&cantidad=100&orden=nombre&iue=PuaNYqpDhRBJ7K80I8WC&S=epqr6c893g5khekkir9s0l6k6n&_=1700488253028");if(!e.ok)throw Error(`Error en la solicitud: ${e.statusText}`);let r=await e.json();return r}catch(e){console.error(`Error en cargarProductos: ${e.message}`)}}async function s(e){try{let r=await fetch(`https://api-beta.saasargentina.com/v1/rubros?idrubro=${e}&desde=0&cantidad=100&orden=nombre&iue=PuaNYqpDhRBJ7K80I8WC&S=epqr6c893g5khekkir9s0l6k6n&_=1700488253028`);if(!r.ok)throw Error(`Error en la solicitud: ${r.statusText}`);let t=await r.json(),n=t.map(e=>({idrubro:e.idrubro,nombre:e.nombre}));return n}catch(e){console.error(`Error en cargarProductos: ${e.message}`)}}async function a(){try{let e=await o(),r=[];for(let t of e){let e=await s(t.idrubro);r.push({parent:t,children:[...e]})}return r}catch(e){throw console.error(`Error in getAllCategoriesAndSubCategories: ${e.message}`),e}}t.d(r,{Q:()=>a,V:()=>n})},6764:()=>{},5244:(e,r)=>{"use strict";var t;Object.defineProperty(r,"x",{enumerable:!0,get:function(){return t}}),function(e){e.PAGES="PAGES",e.PAGES_API="PAGES_API",e.APP_PAGE="APP_PAGE",e.APP_ROUTE="APP_ROUTE"}(t||(t={}))}};