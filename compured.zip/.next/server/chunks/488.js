exports.id=488,exports.ids=[488],exports.modules={6971:(e,t,r)=>{"use strict";r.d(t,{Ku:()=>d,Mp:()=>o,NZ:()=>c,Nh:()=>n,V1:()=>l});var i=r(7518),s=r.n(i);let o=s().div`
    position: relative;
    padding: 30px 12px;
    ${({bgcolor:e})=>e&&`background-color: ${e}`}
`,n=s().div`
    max-width: var(--inner-max-width);
    margin: 0 auto;
    padding: 0 20px;
`,l=s().h1`
    font-size: 2.3rem;
    margin: 15px 0;
`,c=s().h2`
    font-size: 2rem;
`,d=s().p``},6739:(e,t,r)=>{"use strict";r.d(t,{EL:()=>n,Fc:()=>l,K1:()=>s,Z5:()=>o,xN:()=>d,yN:()=>c});var i=r(997);let s=()=>(0,i.jsxs)("svg",{xmlns:"http://www.w3.org/2000/svg",width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[i.jsx("circle",{cx:"11",cy:"11",r:"8"}),i.jsx("line",{x1:"21",y1:"21",x2:"16.65",y2:"16.65"})]}),o=()=>(0,i.jsxs)("svg",{xmlns:"http://www.w3.org/2000/svg",width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[i.jsx("line",{x1:"5",y1:"12",x2:"19",y2:"12"}),i.jsx("polyline",{points:"12 5 19 12 12 19"})]}),n=()=>(0,i.jsxs)("svg",{xmlns:"http://www.w3.org/2000/svg",width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[i.jsx("line",{x1:"19",y1:"12",x2:"5",y2:"12"}),i.jsx("polyline",{points:"12 19 5 12 12 5"})]}),l=()=>(0,i.jsxs)("svg",{xmlns:"http://www.w3.org/2000/svg",width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[i.jsx("circle",{cx:"9",cy:"21",r:"1"}),i.jsx("circle",{cx:"20",cy:"21",r:"1"}),i.jsx("path",{d:"M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"})]}),c=({width:e,height:t,color:r})=>i.jsx("svg",{xmlns:"http://www.w3.org/2000/svg",xlink:"http://www.w3.org/1999/xlink",fill:r,width:"0",height:"0",viewBox:"0 0 30 30",style:{width:e,height:t},children:i.jsx("g",{children:i.jsx("path",{d:"M30.667,14.939c0,8.25-6.74,14.938-15.056,14.938c-2.639,0-5.118-0.675-7.276-1.857L0,30.667l2.717-8.017   c-1.37-2.25-2.159-4.892-2.159-7.712C0.559,6.688,7.297,0,15.613,0C23.928,0.002,30.667,6.689,30.667,14.939z M15.61,2.382   c-6.979,0-12.656,5.634-12.656,12.56c0,2.748,0.896,5.292,2.411,7.362l-1.58,4.663l4.862-1.545c2,1.312,4.393,2.076,6.963,2.076   c6.979,0,12.658-5.633,12.658-12.559C28.27,8.016,22.59,2.382,15.61,2.382z M23.214,18.38c-0.094-0.151-0.34-0.243-0.708-0.427   c-0.367-0.184-2.184-1.069-2.521-1.189c-0.34-0.123-0.586-0.185-0.832,0.182c-0.243,0.367-0.951,1.191-1.168,1.437   c-0.215,0.245-0.43,0.276-0.799,0.095c-0.369-0.186-1.559-0.57-2.969-1.817c-1.097-0.972-1.838-2.169-2.052-2.536   c-0.217-0.366-0.022-0.564,0.161-0.746c0.165-0.165,0.369-0.428,0.554-0.643c0.185-0.213,0.246-0.364,0.369-0.609   c0.121-0.245,0.06-0.458-0.031-0.643c-0.092-0.184-0.829-1.984-1.138-2.717c-0.307-0.732-0.614-0.611-0.83-0.611   c-0.215,0-0.461-0.03-0.707-0.03S9.897,8.215,9.56,8.582s-1.291,1.252-1.291,3.054c0,1.804,1.321,3.543,1.506,3.787   c0.186,0.243,2.554,4.062,6.305,5.528c3.753,1.465,3.753,0.976,4.429,0.914c0.678-0.062,2.184-0.885,2.49-1.739   C23.307,19.268,23.307,18.533,23.214,18.38z"})})}),d=({width:e,height:t,color:r})=>(0,i.jsxs)("svg",{xmlns:"http://www.w3.org/2000/svg",width:e,height:t,viewBox:"0 0 24 24",fill:"none",stroke:r,strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[i.jsx("line",{x1:"12",y1:"5",x2:"12",y2:"19"}),i.jsx("line",{x1:"5",y1:"12",x2:"19",y2:"12"})]})},2995:(e,t,r)=>{"use strict";r.d(t,{Z:()=>c,i:()=>l});var i=r(997);let s=e=>{localStorage.removeItem("cart"),localStorage.setItem("cart",JSON.stringify(e))};var o=r(6689);let n=(0,o.createContext)(),l=()=>(0,o.useContext)(n),c=({children:e})=>{let[t,r]=(0,o.useState)([]);return(0,o.useEffect)(()=>{},[]),console.log(t.length),i.jsx(n.Provider,{value:{cart:t,addItem:(e,i)=>{let o=t.findIndex(t=>t.id===e.idproducto);if(-1===o){let o={id:e.idproducto,name:e.nombre,image:e.archivos[0].imagen,price:e.preciofinal,stock:e.stockactual,qty:i,subtotal:e.preciofinal*i},n=[...t,o];return r(n),s(n),{success:!0,msg:`Agregaste ${i} producto/s al carrito`}}let n=[...t];return n[o].qty===e.stockactual?{success:!1,msg:"No hay m\xe1s stock"}:(n[o].qty+=i,r(n),s(n),{success:!0,msg:`Agregaste ${i} producto/s al carrito`})},removeItem:e=>{let i=t.filter(t=>t.id!==e);s(i),r(i)},cartTotal:(e=0)=>{if(1===t.length)return t[0].subtotal+e;let r=t.reduce((e,t)=>e.subtotal+t.subtotal);return r+e}},children:e})}},6537:(e,t,r)=>{"use strict";r.d(t,{Z:()=>l,u:()=>n});var i=r(997),s=r(6689);let o=(0,s.createContext)(),n=()=>(0,s.useContext)(o),l=({children:e})=>{let[t,r]=(0,s.useState)();return i.jsx(o.Provider,{value:{categories:t,setCategories:r},children:e})}},2488:(e,t,r)=>{"use strict";r.r(t),r.d(t,{default:()=>H});var i=r(997),s=r(2435),o=r.n(s);r(6764);var n=r(6689),l=r(1163),c=r(6739),d=r(7518),a=r.n(d);let x=a().form` 
    display: flex;
    align-items: center;
`,p=a().input`
    width: 100%;
    height: 35px;
    border-radius: 500px 0 0 500px;
    border: 1px solid #cfd7d9;
    padding: 5px 20px;
    font-size: 1rem;
`,h=a().button`
    cursor: pointer;
    border-radius: 0 500px 500px 0;
    border: 1px solid #cfd7d9;
    border-left: none;
    height: 35px;
    padding: 5px;
    width: 65px;
    display: grid;
    place-items: center;

    svg {
        font-size: 1.4rem;
    }
`,u=()=>{let e=(0,l.useRouter)(),t=(0,n.useRef)();return(0,i.jsxs)(x,{onSubmit:r=>{if(r.preventDefault(),t.current&&t?.current?.length!==0){let r=t.current.toLowerCase().trim().normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/[^a-zA-Z0-9 ]/g,"").replace(/\s+/g,"-");e.push(`/productos/${r}`,`/productos/search=${r}`)}},children:[i.jsx(p,{type:"text",name:"term",onChange:e=>t.current=e.target.value}),i.jsx(h,{type:"submit",children:i.jsx(c.K1,{})})]})};var g=r(6537),m=r(2847),j=r(1664),v=r.n(j);let w=a().div`
    position: relative;
`,f=a().button`
    cursor: pointer;
`,b=a().div`
    position: absolute;
    top: 50px;
    padding: 25px;
    background-color: #fff;
    display: grid;
    width: 100vw;
    max-width: 400px;
    max-height: 80vh;
    overflow-y: auto;
    overflow-behaviour: contain;
    box-shadow: var(--light-shadow);
    border-radius: 12px;
`,y=a().button`
    padding: 25px;
    cursor: pointer;
    border-radius: 8px;
    display: flex;
    align-items: center;
    position: relative;

    &:hover {
        background-color: #ededed;

        i {
            right: 25px;
            opacity: 1;
        }
    }
`,k=a().i`
    position: absolute;
    right: 30px;
    transition: all .2s ease-in-out;
    opacity: 0;

    svg {
        font-size: 5px;
    }
`,C=a().div`
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0 25px 25px 20px;
`,L=a().button`
    padding: 25px;
    cursor: pointer;
    border-radius: 8px;
    display: flex;
    align-items: center;
    position: relative;

    &:hover {
        background-color: #ededed;

        i {
            right: 25px;
            opacity: 1;
        }
    }
`,z=a().button`
    cursor: pointer;
`,N=a().button`
    width: 20px;
    height: auto;
    display: grid;
    place-items: center;
    cursor: pointer;

    svg {
        pointer-events: none;
    }
`,S=({children:e})=>{let t=(0,l.useRouter)(),{categories:r}=(0,g.u)(),[s,o]=(0,n.useState)(!1),[d,a]=(0,n.useState)({name:"",id:"",items:[]});(0,n.useEffect)(()=>{let e=e=>{"container"!==e.target.id&&"flyout-btn"!==e.target.id&&(o(!s),a([]))};return s&&window.addEventListener("click",e),s||window.removeEventListener("click",e),()=>window.removeEventListener("click",e)},[s]);let x=(e,r)=>{let i=(0,m.C)(e);t.push(`/productos/${r}`,`/productos/id=${r}&${i}`)};return(0,i.jsxs)(w,{children:[i.jsx(f,{id:"flyout-btn",onClick:()=>o(!s),children:e}),s?i.jsx(b,{id:"container",children:d?.items?.length>0?i.jsx(()=>(0,i.jsxs)(i.Fragment,{children:[(0,i.jsxs)(C,{children:[i.jsx(N,{id:"flyout-btn",onClick:()=>a({name:"",id:"",items:[]}),children:i.jsx(c.EL,{})}),i.jsx(z,{onClick:()=>x(d.name,d.id),children:"Ver todo"})]}),d?.items.map(e=>i.jsxs(L,{onClick:()=>x(e.nombre,e.idrubro),id:"flyout-btn",children:[e.nombre,i.jsx(k,{children:i.jsx(c.Z5,{})})]},e.idrubro))]}),{}):i.jsx(()=>i.jsx(i.Fragment,{children:r?.map(e=>i.jsxs(y,{onClick:()=>a({name:e.parent.nombre,id:e.parent.idrubro,items:e.children}),id:"flyout-btn",children:[e.parent.nombre,i.jsx(k,{children:i.jsx(c.Z5,{})})]},e.parent.idrubro))}),{})}):null]})},Z=a().nav`
    position: relative;
    top: 2px;
    margin-left: 100px;
    display: flex;
    gap: 25px;
    align-items: center;
`,$=a()(v())`
    font-weight: 500;
`,E=()=>(0,i.jsxs)(Z,{children:[i.jsx(S,{children:"Categor\xedas"}),i.jsx($,{href:"/",children:"Servicios"}),i.jsx($,{href:"/",children:"Contacto"})]});var F=r(5675),B=r.n(F);let M=a().header`
    position: relative;
    box-shadow: 0px 5px 11px 0px rgba(25, 141, 179, 0.1);
    z-index: 800;
`,I=a().div`
    max-width: 1500px;
    margin: 0 auto;
    padding: 0 12px;
    display: flex;
    justify-content: space-between;
    display: grid;
    grid-template-columns: minmax(100px, 150px) 1fr minmax(250px, 500px) 50px;
`,W=a()(v())`
    position: relative;
    height: 70px;
`,q=a()(B())`
    object-fit: contain;
`,A=a()(v())`
    display: grid;
    place-items: center;
    margin-left: 10px;
`,K=()=>i.jsx(M,{children:(0,i.jsxs)(I,{children:[i.jsx(W,{href:"/",children:i.jsx(q,{src:"/assets/logo.png",alt:"logo compured",fill:!0,priority:!0})}),i.jsx(E,{}),i.jsx(u,{}),i.jsx(A,{href:"/carrito",children:i.jsx(c.Fc,{})})]})});var R=r(6971);let D=()=>i.jsx(R.Mp,{bgcolor:"#f4f4f4",children:i.jsx(R.Nh,{children:"Footer"})}),P=({children:e})=>(0,i.jsxs)(i.Fragment,{children:[i.jsx(K,{}),i.jsx("main",{children:e}),i.jsx(D,{})]});var V=r(2995);function H({Component:e,pageProps:t}){return i.jsx(V.Z,{children:i.jsx(g.Z,{children:i.jsx(P,{className:o().className,children:i.jsx(e,{...t})})})})}},2847:(e,t,r)=>{"use strict";r.d(t,{C:()=>i});let i=e=>e.toLowerCase().replace(/[^a-z0-9 -]/g,"").replace(/\s+/g,"-").replace(/-+/g,"-").trim()},6764:()=>{}};