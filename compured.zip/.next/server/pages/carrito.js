"use strict";(()=>{var e={};e.id=993,e.ids=[993,888,660],e.modules={1323:(e,r)=>{Object.defineProperty(r,"l",{enumerable:!0,get:function(){return function e(r,t){return t in r?r[t]:"then"in r&&"function"==typeof r.then?r.then(r=>e(r,t)):"function"==typeof r&&"default"===t?r:void 0}}})},8560:(e,r,t)=>{t.r(r),t.d(r,{config:()=>F,default:()=>V,getServerSideProps:()=>Y,getStaticPaths:()=>H,getStaticProps:()=>B,reportWebVitals:()=>U,routeModule:()=>et,unstable_getServerProps:()=>ee,unstable_getServerSideProps:()=>er,unstable_getStaticParams:()=>L,unstable_getStaticPaths:()=>X,unstable_getStaticProps:()=>Z});var i={};t.r(i),t.d(i,{default:()=>K,getStaticProps:()=>O});var a=t(7093),n=t(5244),s=t(1323),o=t(4003),l=t(2488),d=t(997),c=t(6689),p=t(6537),u=t(2995),x=t(6971),h=t(7518),g=t.n(h);let m=g().div`
    width: 100%;
    height: 100vh;
    display: grid;
    place-items: center;
`,f=g().div`
    
    @media all and (min-width: 960px) {
        display: grid;
        grid-template-columns: repeat(12, minmax(0, 1fr));
        column-gap: 10px;    
    }
`,b=g().div`
    border-top: 1px solid var(--soft-gray);
    grid-column: span 7 / span 7;
    margin-right: 50px;
`,j=g().div`
    grid-column: span 5 / span 5;
    max-width: 450px;
`;var v=t(5675),P=t.n(v);let y=g().button`
    cursor: ${({dis:e})=>e?"default":"pointer"};
    color: var(--dark-blue)
`,w=({children:e,onClick:r=()=>{},disabled:t=!1})=>d.jsx(y,{onClick:r,disabled:t,dis:t,children:e}),S=g().div`
    padding: 30px 0;
    border-bottom: 1px solid var(--soft-gray);
    display: flex;
    gap: 30px;
`,k=g().div`
    position: relative;
    padding: 20px;
    overflow: hidden;
    border-radius: 8px;
    border: 1px solid var(--soft-gray);
    flex-shrink: 0;
`,E=g().div`
    position: relative;
`,q=g().h3`
    // font-size: 1rem;
    margin-bottom: 10px;
`,_=g().p`
    font-weight: bold;
    // font-size: 1rem;
    margin-bottom: 10px;
`,A=g().p`
    // font-size: .8rem;
    margin-bottom: 10px;
`,$=({item:e})=>{let{removeItem:r}=(0,u.i)();return(0,d.jsxs)(S,{children:[d.jsx(k,{children:d.jsx(P(),{src:e.image,alt:"",width:100,height:100,style:{objectFit:"contain"}})}),(0,d.jsxs)(E,{children:[d.jsx(q,{children:e.name}),(0,d.jsxs)(_,{children:["$",e.price]}),(0,d.jsxs)(A,{children:["x ",e.qty]}),d.jsx(w,{onClick:()=>r(e.id),children:"Quitar"})]})]})};var C=t(6739);let G=g().div`
    background-color: #f7f7f7;
    border-radius: 12px;
    padding: 35px;
`,I=g().h3`
    margin-bottom: 25px;
`,N=g().div`
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 15px 0;
    border-bottom: 1px solid var(--text-black);
`,R=g().p`
    font-size: .8rem;
    text-overflow: ellipse;
    max-width: 250px;

    span {
        font-weight: bold;
    }
`,z=g().p`
    text-overflow: ellipse;
    max-width: 250px;
    font-weight: bold;
`,T=g().div`
    display: flex;
    justify-content: flex-end;
    align-items: flex-end;
    margin-top: 25px;

    p {
        font-weight: bold;
        margin-left: 35px;
    }
`,D=g().p`
    font-weight: bold;
    margin-left: 35px;
    font-size: 1.5rem;
`,M=g().div`
    background-color: var(--blue);
    color: #fff;
    width: 100%;
    border-radius: 4px;
    padding: 15px;
    display: flex;
    justify-content: center;
    align-items: center;
    margin-top: 25px;
    cursor: pointer;
    transition: all .2s;
    position: relative;

    img {
        position: absolute;
        right: 15px;
        margin-left: 15px;
        object-fit: contain;
        background-color: white;
        color: transparent;
        padding: 4px;
        border-radius: 50px;
        transition: right .2s;
    }

    i {
        position: absolute;
        opacity: 0;
        right: 5px;
        transition: all .2s;
    }

    &:hover {
        background-color: var(--dark-blue);

        img {
            right: 40px;
        }

        i {
            right: 10px;
            opacity: 1;
        }
    }
`,Q=({cart:e})=>{let{cartTotal:r}=(0,u.i)();return(0,d.jsxs)(G,{children:[d.jsx(I,{children:"Resumen de la compra"}),e.map(e=>(0,d.jsxs)(N,{children:[(0,d.jsxs)(R,{children:[e.name," ",(0,d.jsxs)("span",{children:["(x",e.qty,")"]})]}),(0,d.jsxs)("p",{children:["$",e.subtotal]})]},e.id)),(0,d.jsxs)(N,{children:[d.jsx(z,{children:"Subtotal"}),(0,d.jsxs)(z,{children:["$",r()]})]}),(0,d.jsxs)(N,{children:[d.jsx(R,{children:"Env\xedo"}),(0,d.jsxs)("p",{children:["$",3500]})]}),(0,d.jsxs)(T,{children:[d.jsx("p",{children:"Total"}),(0,d.jsxs)(D,{children:["$",r(3500)]})]}),(0,d.jsxs)(M,{onClick:()=>r(),children:["Pagar",d.jsx(P(),{src:"https://drive.google.com/uc?export=view&id=1yhHhZtJGhdeDkqq_qAKyiQ9hC-EgEsQc",alt:"",width:50,height:25}),d.jsx("i",{children:d.jsx(C.Z5,{})})]})]})},W=({categs:e})=>{let{cart:r}=(0,u.i)(),{setCategories:t}=(0,p.u)();return((0,c.useEffect)(()=>t(e),[]),0===r.length)?d.jsx(x.Mp,{children:d.jsx(x.Nh,{children:d.jsx(m,{children:"No hay nada en el carrito"})})}):d.jsx(x.Mp,{children:(0,d.jsxs)(x.Nh,{children:[d.jsx(x.V1,{children:"Carrito"}),(0,d.jsxs)(f,{children:[d.jsx(b,{children:r.map(e=>d.jsx($,{item:e},e.id))}),d.jsx(j,{children:d.jsx(Q,{cart:r})})]})]})})};var J=t(5861);let K=({categories:e})=>d.jsx(W,{categs:e});async function O(){let e=await (0,J.Q)();return{props:{categories:e},revalidate:10}}let V=(0,s.l)(i,"default"),B=(0,s.l)(i,"getStaticProps"),H=(0,s.l)(i,"getStaticPaths"),Y=(0,s.l)(i,"getServerSideProps"),F=(0,s.l)(i,"config"),U=(0,s.l)(i,"reportWebVitals"),Z=(0,s.l)(i,"unstable_getStaticProps"),X=(0,s.l)(i,"unstable_getStaticPaths"),L=(0,s.l)(i,"unstable_getStaticParams"),ee=(0,s.l)(i,"unstable_getServerProps"),er=(0,s.l)(i,"unstable_getServerSideProps"),et=new a.PagesRouteModule({definition:{kind:n.x.PAGES,page:"/carrito",pathname:"/carrito",bundlePath:"",filename:""},components:{App:l.default,Document:o.default},userland:i})},4003:(e,r,t)=>{t.r(r),t.d(r,{default:()=>o});var i=t(997),a=t(6859),n=t.n(a),s=t(7518);class o extends n(){static async getInitialProps(e){let r=new s.ServerStyleSheet,t=e.renderPage;try{e.renderPage=()=>t({enhanceApp:e=>t=>r.collectStyles(i.jsx(e,{...t}))});let a=await n().getInitialProps(e);return{...a,styles:(0,i.jsxs)(i.Fragment,{children:[a.styles,r.getStyleElement()]})}}finally{r.seal()}}render(){return(0,i.jsxs)(a.Html,{lang:"en",children:[i.jsx(a.Head,{}),(0,i.jsxs)("body",{children:[i.jsx(a.Main,{}),i.jsx(a.NextScript,{})]})]})}}},5861:(e,r,t)=>{async function i(e){let r=[1,2],t=[];for(let i=0;i<r.length;i++)t.push(await a(r[i],e));let i=new Set(t.map(e=>e.idproducto));return t=[...i].map(e=>t.find(r=>r.idproducto===e))}async function a(e,r){try{let t=await fetch(`https://api-beta.saasargentina.com/v1/productos?busqueda=&datosextras=&desde=0&cantidad=100&iddeposito=${e}&mostrarimagenes=1&idrubro=${r}&orden=nombre&iue=PuaNYqpDhRBJ7K80I8WC&S=epqr6c893g5khekkir9s0l6k6n&_=1700488253028`);if(!t.ok)throw Error(`Error en la solicitud: ${t.statusText}`);let i=await t.json();return i.resultados}catch(e){console.error(`Error en cargarProductos: ${e.message}`)}}async function n(){try{let e=await fetch("https://api-beta.saasargentina.com/v1/rubros?idrubro=0&desde=0&cantidad=100&orden=nombre&iue=PuaNYqpDhRBJ7K80I8WC&S=epqr6c893g5khekkir9s0l6k6n&_=1700488253028");if(!e.ok)throw Error(`Error en la solicitud: ${e.statusText}`);let r=await e.json();return r}catch(e){console.error(`Error en cargarProductos: ${e.message}`)}}async function s(e){try{let r=await fetch(`https://api-beta.saasargentina.com/v1/rubros?idrubro=${e}&desde=0&cantidad=100&orden=nombre&iue=PuaNYqpDhRBJ7K80I8WC&S=epqr6c893g5khekkir9s0l6k6n&_=1700488253028`);if(!r.ok)throw Error(`Error en la solicitud: ${r.statusText}`);let t=await r.json(),i=t.map(e=>({idrubro:e.idrubro,nombre:e.nombre}));return i}catch(e){console.error(`Error en cargarProductos: ${e.message}`)}}async function o(){try{let e=await n(),r=[];for(let t of e){let e=await s(t.idrubro);r.push({parent:t,children:[...e]})}return r}catch(e){throw console.error(`Error in getAllCategoriesAndSubCategories: ${e.message}`),e}}t.d(r,{Q:()=>o,V:()=>i})},5244:(e,r)=>{var t;Object.defineProperty(r,"x",{enumerable:!0,get:function(){return t}}),function(e){e.PAGES="PAGES",e.PAGES_API="PAGES_API",e.APP_PAGE="APP_PAGE",e.APP_ROUTE="APP_ROUTE"}(t||(t={}))},2785:e=>{e.exports=require("next/dist/compiled/next-server/pages.runtime.prod.js")},6689:e=>{e.exports=require("react")},6405:e=>{e.exports=require("react-dom")},997:e=>{e.exports=require("react/jsx-runtime")},7518:e=>{e.exports=require("styled-components")},7147:e=>{e.exports=require("fs")},1017:e=>{e.exports=require("path")},2781:e=>{e.exports=require("stream")},9796:e=>{e.exports=require("zlib")}};var r=require("../webpack-runtime.js");r.C(e);var t=e=>r(r.s=e),i=r.X(0,[428,571,859,488],()=>t(8560));module.exports=i})();