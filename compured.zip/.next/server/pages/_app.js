(()=>{var e={};e.id=888,e.ids=[888],e.modules={6537:(e,r,t)=>{"use strict";t.d(r,{Z:()=>d,u:()=>o});var i=t(997),s=t(6689);let n=(0,s.createContext)(),o=()=>(0,s.useContext)(n),d=({children:e})=>{let[r,t]=(0,s.useState)();return i.jsx(n.Provider,{value:{categories:r,setCategories:t},children:e})}},5401:(e,r,t)=>{"use strict";t.r(r),t.d(r,{default:()=>H});var i=t(997),s=t(2435),n=t.n(s);t(6764);var o=t(6689);let d=()=>(0,i.jsxs)("svg",{xmlns:"http://www.w3.org/2000/svg",width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[i.jsx("circle",{cx:"11",cy:"11",r:"8"}),i.jsx("line",{x1:"21",y1:"21",x2:"16.65",y2:"16.65"})]}),l=()=>(0,i.jsxs)("svg",{xmlns:"http://www.w3.org/2000/svg",width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[i.jsx("line",{x1:"5",y1:"12",x2:"19",y2:"12"}),i.jsx("polyline",{points:"12 5 19 12 12 19"})]}),a=()=>(0,i.jsxs)("svg",{xmlns:"http://www.w3.org/2000/svg",width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[i.jsx("line",{x1:"19",y1:"12",x2:"5",y2:"12"}),i.jsx("polyline",{points:"12 19 5 12 12 5"})]});var c=t(7518),p=t.n(c);let x=p().form` 
    display: flex;
    align-items: center;
`,u=p().input`
    width: 100%;
    height: 35px;
    border-radius: 500px 0 0 500px;
    border: 1px solid #cfd7d9;
    padding: 5px 20px;
    font-size: 1rem;
`,h=p().button`
    cursor: pointer;
    border-radius: 0 500px 500px 0;
    border: 1px solid #cfd7d9;
    border-left: none;
    height: 35px;
    padding: 5px;
    width: 65px;
    display: grid;
    place-items: center;

    svg {
        font-size: 1.4rem;
    }
`,g=async e=>{let r=await fetch("https://api-beta.saasargentina.com/v1/productos?callback=productoscallback&busqueda=Auriculares&datosextras=&desde=0&cantidad=100&mostrarimagenes=1&idrubro=0&orden=nombre");console.log(r);let t=await r.json();console.log(t)},m=()=>{let e=(0,o.useRef)();return(0,i.jsxs)(x,{onSubmit:r=>{if(r.preventDefault(),e.current&&e?.current?.length!==0){let r=e.current.toLowerCase().trim().normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/[^a-zA-Z0-9 ]/g,"").replace(/\s+/g,"-");g(r)}},children:[i.jsx(u,{type:"text",name:"term",onChange:r=>e.current=r.target.value}),i.jsx(h,{type:"submit",children:i.jsx(d,{})})]})};var j=t(1163),v=t(6537);let b=e=>e.toLowerCase().replace(/[^a-z0-9 -]/g,"").replace(/\s+/g,"-").replace(/-+/g,"-").trim();var f=t(1664),w=t.n(f);let y=p().div`
    position: relative;
`,k=p().button`
    cursor: pointer;
`,C=p().div`
    position: absolute;
    top: 50px;
    padding: 25px;
    background-color: #fff;
    display: grid;
    width: 100vw;
    max-width: 400px;
    max-height: 80vh;
    overflow-y: scroll;
    box-shadow: var(--light-shadow);
    border-radius: 12px;
`,L=p().button`
    padding: 25px;
    cursor: pointer;
    border-radius: 8px;
    display: flex;
    align-items: center;
    position: relative;

    &:hover {
        background-color: #ededed;

        i {
            right: 25px;
            opacity: 1;
        }
    }
`,q=p().i`
    position: absolute;
    right: 30px;
    transition: all .2s ease-in-out;
    opacity: 0;

    svg {
        font-size: 5px;
    }
`,z=p().div`
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0 25px 25px 20px;
`,S=p().button`
    padding: 25px;
    cursor: pointer;
    border-radius: 8px;
    display: flex;
    align-items: center;
    position: relative;

    &:hover {
        background-color: #ededed;

        i {
            right: 25px;
            opacity: 1;
        }
    }
`,E=p().button`
    cursor: pointer;
`,F=p().button`
    width: 20px;
    height: auto;
    display: grid;
    place-items: center;
    cursor: pointer;

    svg {
        pointer-events: none;
    }
`,B=({children:e})=>{let r=(0,j.useRouter)(),{categories:t}=(0,v.u)(),[s,n]=(0,o.useState)(!1),[d,c]=(0,o.useState)({name:"",id:"",items:[]});(0,o.useEffect)(()=>{let e=e=>{"container"!==e.target.id&&"flyout-btn"!==e.target.id&&(n(!s),c([]))};return s&&window.addEventListener("click",e),s||window.removeEventListener("click",e),()=>window.removeEventListener("click",e)},[s]);let p=(e,t)=>{let i=b(e);r.push(`/productos/${t}`,`/productos/id=${t}&${i}`)};return(0,i.jsxs)(y,{children:[i.jsx(k,{id:"flyout-btn",onClick:()=>n(!s),children:e}),s?i.jsx(C,{id:"container",children:d?.items?.length>0?i.jsx(()=>(0,i.jsxs)(i.Fragment,{children:[(0,i.jsxs)(z,{children:[i.jsx(F,{id:"flyout-btn",onClick:()=>c({name:"",id:"",items:[]}),children:i.jsx(a,{})}),i.jsx(E,{onClick:()=>p(d.name,d.id),children:"Ver todo"})]}),d?.items.map(e=>i.jsxs(S,{onClick:()=>p(e.nombre,e.idrubro),id:"flyout-btn",children:[e.nombre,i.jsx(q,{children:i.jsx(l,{})})]},e.idrubro))]}),{}):i.jsx(()=>i.jsx(i.Fragment,{children:t?.map(e=>i.jsxs(L,{onClick:()=>c({name:e.parent.nombre,id:e.parent.idrubro,items:e.children}),id:"flyout-btn",children:[e.parent.nombre,i.jsx(q,{children:i.jsx(l,{})})]},e.parent.idrubro))}),{})}):null]})},N=p().nav`
    position: relative;
    top: 2px;
    margin-left: 100px;
    display: flex;
    gap: 25px;
    align-items: center;
`,W=p()(w())`
    font-weight: 500;
`,Z=()=>(0,i.jsxs)(N,{children:[i.jsx(B,{children:"Categor\xedas"}),i.jsx(W,{href:"/",children:"Servicios"}),i.jsx(W,{href:"/",children:"Contacto"})]});var $=t(5675),A=t.n($);let D=p().header`
    position: relative;
    box-shadow: 0px 5px 11px 0px rgba(25, 141, 179, 0.1);
    z-index: 800;
`,R=p().div`
    max-width: 1500px;
    margin: 0 auto;
    padding: 0 12px;
    display: flex;
    justify-content: space-between;
    display: grid;
    grid-template-columns: minmax(100px, 150px) 1fr minmax(250px, 500px);
`,P=p()(w())`
    position: relative;
    height: 70px;
`,V=p()(A())`
    object-fit: contain;
`,X=()=>i.jsx(D,{children:(0,i.jsxs)(R,{children:[i.jsx(P,{href:"/",children:i.jsx(V,{src:"/assets/logo.png",alt:"logo compured",fill:!0,priority:!0})}),i.jsx(Z,{}),i.jsx(m,{})]})}),G=({children:e})=>(0,i.jsxs)(i.Fragment,{children:[i.jsx(X,{}),i.jsx("main",{children:e})]});function H({Component:e,pageProps:r}){return i.jsx(v.Z,{children:i.jsx(G,{className:n().className,children:i.jsx(e,{...r})})})}},6764:()=>{},2785:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/pages.runtime.prod.js")},6689:e=>{"use strict";e.exports=require("react")},6405:e=>{"use strict";e.exports=require("react-dom")},997:e=>{"use strict";e.exports=require("react/jsx-runtime")},7518:e=>{"use strict";e.exports=require("styled-components")},7147:e=>{"use strict";e.exports=require("fs")},2781:e=>{"use strict";e.exports=require("stream")},9796:e=>{"use strict";e.exports=require("zlib")}};var r=require("../webpack-runtime.js");r.C(e);var t=e=>r(r.s=e),i=r.X(0,[428,571],()=>t(5401));module.exports=i})();