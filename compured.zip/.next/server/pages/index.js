(()=>{var e={};e.id=405,e.ids=[405],e.modules={5819:(e,t,r)=>{"use strict";r.a(e,async(e,i)=>{try{r.r(t),r.d(t,{config:()=>g,default:()=>c,getServerSideProps:()=>h,getStaticPaths:()=>x,getStaticProps:()=>u,reportWebVitals:()=>v,routeModule:()=>y,unstable_getServerProps:()=>j,unstable_getServerSideProps:()=>f,unstable_getStaticParams:()=>b,unstable_getStaticPaths:()=>w,unstable_getStaticProps:()=>m});var s=r(7093),a=r(5244),o=r(1323),n=r(4003),d=r(5401),p=r(9798),l=e([p]);p=(l.then?(await l)():l)[0];let c=(0,o.l)(p,"default"),u=(0,o.l)(p,"getStaticProps"),x=(0,o.l)(p,"getStaticPaths"),h=(0,o.l)(p,"getServerSideProps"),g=(0,o.l)(p,"config"),v=(0,o.l)(p,"reportWebVitals"),m=(0,o.l)(p,"unstable_getStaticProps"),w=(0,o.l)(p,"unstable_getStaticPaths"),b=(0,o.l)(p,"unstable_getStaticParams"),j=(0,o.l)(p,"unstable_getServerProps"),f=(0,o.l)(p,"unstable_getServerSideProps"),y=new s.PagesRouteModule({definition:{kind:a.x.PAGES,page:"/index",pathname:"/",bundlePath:"",filename:""},components:{App:d.default,Document:n.default},userland:p});i()}catch(e){i(e)}})},7472:(e,t,r)=>{"use strict";r.a(e,async(e,i)=>{try{r.d(t,{Z:()=>p});var s=r(997),a=r(4682),o=r(3015),n=r(2184);r(7644),r(5392);var d=e([o,n]);[o,n]=d.then?(await d)():d;let p=()=>s.jsx(a.W,{children:(0,s.jsxs)(o.Swiper,{autoplay:{delay:2500,disableOnInteraction:!1},pagination:{dynamicBullets:!0},modules:[n.Autoplay,n.Pagination],className:"mySwiper",children:[s.jsx(o.SwiperSlide,{children:s.jsx(a.E,{src:"/assets/banner-placeholder.png",alt:"",width:1920,height:400,priority:!0})}),s.jsx(o.SwiperSlide,{children:s.jsx(a.E,{src:"/assets/banner-placeholder.png",alt:"",width:1920,height:400,priority:!0})}),s.jsx(o.SwiperSlide,{children:s.jsx(a.E,{src:"/assets/banner-placeholder.png",alt:"",width:1920,height:400,priority:!0})}),s.jsx(o.SwiperSlide,{children:s.jsx(a.E,{src:"/assets/banner-placeholder.png",alt:"",width:1920,height:400,priority:!0})})]})});i()}catch(e){i(e)}})},4682:(e,t,r)=>{"use strict";r.d(t,{E:()=>d,W:()=>n});var i=r(7518),s=r.n(i),a=r(5675),o=r.n(a);let n=s().div`
    width: 100%;
    margin: 0 auto;
    border-radius: 30px;
    overflow: hidden;
`,d=s()(o())`
    width: 100%;
    display: block;
    object-fit: cover;
`},6971:(e,t,r)=>{"use strict";r.d(t,{Ku:()=>d,Mp:()=>a,NZ:()=>n,Nh:()=>o});var i=r(7518),s=r.n(i);let a=s().div`
    position: relative;
    padding: 30px 12px;
`,o=s().div`
    max-width: var(--inner-max-width);
    margin: 0 auto;
    padding: 0 20px;
`,n=s().h2`
    font-size: 2rem;
`,d=s().p``},7267:(e,t,r)=>{"use strict";r.a(e,async(e,i)=>{try{r.d(t,{Z:()=>d});var s=r(997),a=r(6971),o=r(6990),n=e([o]);o=(n.then?(await n)():n)[0];let d=({products:e})=>(0,s.jsxs)("section",{children:[s.jsx(a.NZ,{children:"Novedades"}),s.jsx(a.Ku,{children:"Destacados y recomendados"}),s.jsx(o.Z,{products:e})]});i()}catch(e){i(e)}})},7967:(e,t,r)=>{"use strict";r.d(t,{l:()=>a});var i=r(7518),s=r.n(i);let a=s().div`
    display: flex;
    flex-direction: column;
    gap: 40px;
`},9687:(e,t,r)=>{"use strict";r.a(e,async(e,i)=>{try{r.d(t,{Z:()=>u});var s=r(997),a=r(6689),o=r(6537),n=r(6971),d=r(7967),p=r(7472),l=r(7267),c=e([p,l]);[p,l]=c.then?(await c)():c;let u=({children:e,products:t,categs:r})=>{let{setCategories:i}=(0,o.u)();return(0,a.useEffect)(()=>i(r),[]),s.jsx(n.Mp,{children:s.jsx(n.Nh,{children:(0,s.jsxs)(d.l,{children:[s.jsx(p.Z,{}),s.jsx(l.Z,{products:t}),e]})})})};i()}catch(e){i(e)}})},982:(e,t,r)=>{"use strict";r.d(t,{Z:()=>v});var i=r(997),s=r(7518),a=r.n(s),o=r(1664),n=r.n(o),d=r(5675),p=r.n(d);let l=a()(n())`
    width: 100%;
    border-radius: 8px;
    height: 330px;
    display: inline-block;
    padding: 3px 3px 14px;
    box-shadow: var(--light-shadow);
    border: 1px solid rgba(25, 141, 179, 0.1);
`,c=a().div`
    position: relative;
    width: 100%;
    height: 150px;
`,u=a().div`
    position: relative;
    margin-top: 15px;
    padding: 0 15px;

    &:after {
        content: "";
        position: absolute;
        height: 1px;
        width: calc(100% - 15px);
        top: -10px;
        left: 50%;
        transform: translateX(-50%);
        background-color: var(--soft-gray);
    }
`,x=a()(p())`
    object-fit: contain;
`,h=a().p`
    white-space: nowrap; 
    overflow: hidden;
    text-overflow: ellipsis;
    margin-bottom: 15px;
`,g=a().p`
    font-size: 1.5rem;
    margin-bottom: 15px;
`,Text=a().p`
    color: var(--text-light);
    font-size: 0.8em;
`,v=({product:e})=>(0,i.jsxs)(l,{href:`/producto/${e.idproducto}`,children:[i.jsx(c,{children:i.jsx(x,{src:e.imagen_url,alt:e.nombre,fill:!0})}),(0,i.jsxs)(u,{children:[i.jsx(h,{children:e.nombre}),(0,i.jsxs)(g,{children:["$",e.preciofinal]}),i.jsx(Text,{children:e.nombre})]})]})},8073:(e,t,r)=>{"use strict";r.d(t,{I:()=>o,h:()=>a});var i=r(7518),s=r.n(i);let a=s().div`
    position: absolute;
    top: 50%;
    left: -22px;
    transform: translateY(-75%);
    display: grid;
    place-items: center;
    width: 55px;
    height: 55px;
    cursor: pointer;
    z-index: 200;
    border-radius: 500px;
    background-color: #ededed;
    opacity: .5;
    transition: opacity .2s;

    svg {
        font-size: 30px;
        position: relative;
        left: 5px;

        path {
            color: var(--blue);
        }
    }

    &:hover {
        opacity: 1;
    }
`,o=s().div`
    position: absolute;
    top: 50%;
    right: -22px;
    transform: translateY(-75%);
    display: grid;
    place-items: center;
    width: 55px;
    height: 55px;
    cursor: pointer;
    z-index: 200;
    border-radius: 500px;
    background-color: #ededed;
    opacity: .5;
    transition: opacity .2s;

    svg {
        font-size: 30px;
        position: relative;
        right: 5px;

        path {
            color: var(--blue);
        }
    }

    &:hover {
        opacity: 1;
    }
`},5092:(e,t,r)=>{"use strict";r.a(e,async(e,i)=>{try{r.d(t,{Z:()=>d});var s=r(997),a=r(3015),o=r(8073),n=e([a]);a=(n.then?(await n)():n)[0];let d=()=>{let e=(0,a.useSwiper)();return(0,s.jsxs)(s.Fragment,{children:[s.jsx(o.h,{onClick:()=>e.slidePrev()}),s.jsx(o.I,{onClick:()=>e.slideNext()})]})};i()}catch(e){i(e)}})},2246:(e,t,r)=>{"use strict";r.d(t,{mn:()=>a});var i=r(7518),s=r.n(i);let a=s().div`
    position: relative;
    z-index: 0;

    .mySwiper {
        padding: 1rem 0 3rem 0;
    }
`;s().div`
    position: absolute;
    top: 50%;
    left: -22px;
    transform: translateY(-75%);
    display: grid;
    place-items: center;
    width: 55px;
    height: 55px;
    cursor: pointer;
    z-index: 200;
    border-radius: 500px;
    background-color: #ededed;

    svg {
        font-size: 30px;
        position: relative;
        left: 5px;
    }
`,s().div`
    position: absolute;
    top: 50%;
    right: -22px;
    transform: translateY(-75%);
    display: grid;
    place-items: center;
    width: 55px;
    height: 55px;
    cursor: pointer;
    z-index: 200;
    border-radius: 500px;
    background-color: #ededed;

    svg {
        font-size: 30px;
        position: relative;
        right: 5px;
    }
`},6990:(e,t,r)=>{"use strict";r.a(e,async(e,i)=>{try{r.d(t,{Z:()=>c});var s=r(997),a=r(3015),o=r(2184);r(7644),r(4700),r(5392),r(3039);var n=r(982),d=r(2246),p=r(5092),l=e([a,o,p]);[a,o,p]=l.then?(await l)():l;let c=({products:e})=>s.jsx(d.mn,{children:(0,s.jsxs)(a.Swiper,{breakpoints:{500:{slidesPerView:1},640:{slidesPerView:2,spaceBetween:20},768:{slidesPerView:3},1024:{slidesPerView:5,spaceBetween:30}},spaceBetween:30,pagination:{clickable:!1},modules:[o.Pagination,o.Navigation],className:"mySwiper",children:[e.map(e=>s.jsx(a.SwiperSlide,{children:s.jsx(n.Z,{product:e})},e.idproducto)),s.jsx(p.Z,{})]})});i()}catch(e){i(e)}})},9798:(e,t,r)=>{"use strict";r.a(e,async(e,i)=>{try{r.r(t),r.d(t,{default:()=>l,getStaticProps:()=>c});var s=r(997),a=r(968),o=r.n(a),n=r(5861),d=r(9687),p=e([d]);function l({products:e,categories:t}){return(0,s.jsxs)(s.Fragment,{children:[(0,s.jsxs)(o(),{children:[s.jsx("title",{children:"Compured"}),s.jsx("meta",{name:"description",content:"Descripcion compured"}),s.jsx("meta",{name:"viewport",content:"width=device-width, initial-scale=1"}),s.jsx("link",{rel:"icon",href:"/favicon.ico"})]}),s.jsx(d.Z,{products:e,categs:t})]})}async function c(){let e=await (0,n.V)(129),t=await (0,n.Q)();return{props:{products:e[0],categories:t},revalidate:10}}d=(p.then?(await p)():p)[0],i()}catch(e){i(e)}})},4700:()=>{},3039:()=>{},5392:()=>{},7644:()=>{},2785:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/pages.runtime.prod.js")},968:e=>{"use strict";e.exports=require("next/head")},6689:e=>{"use strict";e.exports=require("react")},6405:e=>{"use strict";e.exports=require("react-dom")},997:e=>{"use strict";e.exports=require("react/jsx-runtime")},7518:e=>{"use strict";e.exports=require("styled-components")},2184:e=>{"use strict";e.exports=import("swiper/modules")},3015:e=>{"use strict";e.exports=import("swiper/react")},7147:e=>{"use strict";e.exports=require("fs")},1017:e=>{"use strict";e.exports=require("path")},2781:e=>{"use strict";e.exports=require("stream")},9796:e=>{"use strict";e.exports=require("zlib")}};var t=require("../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),i=t.X(0,[428,571,859,158],()=>r(5819));module.exports=i})();