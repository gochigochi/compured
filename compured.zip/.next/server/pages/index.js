(()=>{var e={};e.id=405,e.ids=[405,888,660],e.modules={1323:(e,t)=>{"use strict";Object.defineProperty(t,"l",{enumerable:!0,get:function(){return function e(t,r){return r in t?t[r]:"then"in t&&"function"==typeof t.then?t.then(t=>e(t,r)):"function"==typeof t&&"default"===r?t:void 0}}})},5819:(e,t,r)=>{"use strict";r.a(e,async(e,i)=>{try{r.r(t),r.d(t,{config:()=>g,default:()=>p,getServerSideProps:()=>x,getStaticPaths:()=>h,getStaticProps:()=>u,reportWebVitals:()=>f,routeModule:()=>j,unstable_getServerProps:()=>w,unstable_getServerSideProps:()=>y,unstable_getStaticParams:()=>v,unstable_getStaticPaths:()=>b,unstable_getStaticProps:()=>m});var s=r(7093),a=r(5244),n=r(1323),o=r(4003),l=r(2488),d=r(9798),c=e([d]);d=(c.then?(await c)():c)[0];let p=(0,n.l)(d,"default"),u=(0,n.l)(d,"getStaticProps"),h=(0,n.l)(d,"getStaticPaths"),x=(0,n.l)(d,"getServerSideProps"),g=(0,n.l)(d,"config"),f=(0,n.l)(d,"reportWebVitals"),m=(0,n.l)(d,"unstable_getStaticProps"),b=(0,n.l)(d,"unstable_getStaticPaths"),v=(0,n.l)(d,"unstable_getStaticParams"),w=(0,n.l)(d,"unstable_getServerProps"),y=(0,n.l)(d,"unstable_getServerSideProps"),j=new s.PagesRouteModule({definition:{kind:a.x.PAGES,page:"/index",pathname:"/",bundlePath:"",filename:""},components:{App:l.default,Document:o.default},userland:d});i()}catch(e){i(e)}})},7472:(e,t,r)=>{"use strict";r.a(e,async(e,i)=>{try{r.d(t,{Z:()=>d});var s=r(997),a=r(4682),n=r(3015),o=r(2184);r(7644),r(5392);var l=e([n,o]);[n,o]=l.then?(await l)():l;let d=()=>s.jsx(a.W,{children:(0,s.jsxs)(n.Swiper,{autoplay:{delay:2500,disableOnInteraction:!1},pagination:{dynamicBullets:!0},modules:[o.Autoplay,o.Pagination],className:"mySwiper",children:[s.jsx(n.SwiperSlide,{children:s.jsx(a.E,{src:"/assets/banner-placeholder.png",alt:"",width:1920,height:400,priority:!0})}),s.jsx(n.SwiperSlide,{children:s.jsx(a.E,{src:"/assets/banner-placeholder.png",alt:"",width:1920,height:400,priority:!0})}),s.jsx(n.SwiperSlide,{children:s.jsx(a.E,{src:"/assets/banner-placeholder.png",alt:"",width:1920,height:400,priority:!0})}),s.jsx(n.SwiperSlide,{children:s.jsx(a.E,{src:"/assets/banner-placeholder.png",alt:"",width:1920,height:400,priority:!0})})]})});i()}catch(e){i(e)}})},4682:(e,t,r)=>{"use strict";r.d(t,{E:()=>l,W:()=>o});var i=r(7518),s=r.n(i),a=r(5675),n=r.n(a);let o=s().div`
    width: 100%;
    margin: 0 auto;
    border-radius: 20px;
    overflow: hidden;
`,l=s()(n())`
    width: 100%;
    display: block;
    object-fit: cover;
`},7267:(e,t,r)=>{"use strict";r.a(e,async(e,i)=>{try{r.d(t,{Z:()=>l});var s=r(997),a=r(6971),n=r(6990),o=e([n]);n=(o.then?(await o)():o)[0];let l=({products:e})=>(0,s.jsxs)("section",{children:[s.jsx(a.NZ,{children:"Novedades"}),s.jsx(a.Ku,{children:"Destacados y recomendados"}),s.jsx(n.Z,{products:e})]});i()}catch(e){i(e)}})},7967:(e,t,r)=>{"use strict";r.d(t,{l:()=>a});var i=r(7518),s=r.n(i);let a=s().div`
    display: flex;
    flex-direction: column;
    gap: 40px;
`},9687:(e,t,r)=>{"use strict";r.a(e,async(e,i)=>{try{r.d(t,{Z:()=>m});var s=r(997),a=r(5152),n=r.n(a),o=r(6689),l=r(6197),d=r(6537),c=r(6971),p=r(7967),u=r(7472),h=r(7267),x=e([l,u,h]);[l,u,h]=x.then?(await x)():x;let g=n()(()=>r.e(515).then(r.bind(r,4515)),{loadableGenerated:{modules:["..\\components\\home\\Home.jsx -> ./services/Services"]}}),f=n()(()=>r.e(950).then(r.bind(r,6950)),{loadableGenerated:{modules:["..\\components\\home\\Home.jsx -> ./clients/Clients"]}}),m=({children:e,products:t,categs:r})=>{let{setCategories:i}=(0,d.u)(),a=(0,o.useRef)(),n=(0,o.useRef)(),x=(0,l.useInView)(a,{once:!0}),m=(0,l.useInView)(n,{once:!0});return(0,o.useEffect)(()=>i(r),[]),s.jsx(c.Mp,{children:s.jsx(c.Nh,{children:(0,s.jsxs)(p.l,{children:[s.jsx(u.Z,{}),s.jsx(h.Z,{products:t}),s.jsx("div",{ref:n}),m?s.jsx(g,{}):null,s.jsx("div",{ref:a}),x?s.jsx(f,{}):null,e]})})})};i()}catch(e){i(e)}})},982:(e,t,r)=>{"use strict";r.d(t,{Z:()=>f});var i=r(997),s=r(1163),a=r(2847),n=r(7518),o=r.n(n),l=r(5675),d=r.n(l);let c=o().button`
    width: 100%;
    border-radius: 8px;
    height: 330px;
    display: inline-block;
    padding: 3px 3px 14px;
    box-shadow: var(--light-shadow);
    border: 1px solid rgba(25, 141, 179, 0.1);
`,p=o().div`
    position: relative;
    width: 100%;
    height: 150px;
`,u=o().div`
    position: relative;
    margin-top: 15px;
    padding: 0 15px;

    &:after {
        content: "";
        position: absolute;
        height: 1px;
        width: calc(100% - 15px);
        top: -10px;
        left: 50%;
        transform: translateX(-50%);
        background-color: var(--soft-gray);
    }
`,h=o()(d())`
    object-fit: contain;
`,x=o().p`
    white-space: nowrap; 
    overflow: hidden;
    text-overflow: ellipsis;
    margin-bottom: 15px;
`,g=o().p`
    font-size: 1.5rem;
    margin-bottom: 15px;
`,Text=o().p`
    color: var(--text-light);
    font-size: 0.8em;
`,f=({product:e})=>{let t=(0,s.useRouter)(),r=(e,r)=>{let i=(0,a.C)(e);t.push(`/producto/${r}`,`/producto/id=${r}&${i}`)};return(0,i.jsxs)(c,{onClick:()=>r(e.nombre,e.idproducto),children:[i.jsx(p,{children:i.jsx(h,{src:e.imagen_url,alt:e.nombre,fill:!0})}),(0,i.jsxs)(u,{children:[i.jsx(x,{children:e.nombre}),(0,i.jsxs)(g,{children:["$",e.preciofinal]}),i.jsx(Text,{children:e.nombre})]})]})}},8073:(e,t,r)=>{"use strict";r.d(t,{I:()=>n,h:()=>a});var i=r(7518),s=r.n(i);let a=s().div`
    position: absolute;
    top: 50%;
    left: -22px;
    transform: translateY(-75%);
    display: grid;
    place-items: center;
    width: 55px;
    height: 55px;
    cursor: pointer;
    z-index: 200;
    border-radius: 500px;
    background-color: #ededed;
    opacity: .5;
    transition: opacity .2s;

    svg {
        font-size: 30px;
        position: relative;
        left: 5px;

        path {
            color: var(--blue);
        }
    }

    &:hover {
        opacity: 1;
    }
`,n=s().div`
    position: absolute;
    top: 50%;
    right: -22px;
    transform: translateY(-75%);
    display: grid;
    place-items: center;
    width: 55px;
    height: 55px;
    cursor: pointer;
    z-index: 200;
    border-radius: 500px;
    background-color: #ededed;
    opacity: .5;
    transition: opacity .2s;

    svg {
        font-size: 30px;
        position: relative;
        right: 5px;

        path {
            color: var(--blue);
        }
    }

    &:hover {
        opacity: 1;
    }
`},5092:(e,t,r)=>{"use strict";r.a(e,async(e,i)=>{try{r.d(t,{Z:()=>d});var s=r(997),a=r(3015),n=r(8073),o=r(6739),l=e([a]);a=(l.then?(await l)():l)[0];let d=()=>{let e=(0,a.useSwiper)();return(0,s.jsxs)(s.Fragment,{children:[s.jsx(n.h,{onClick:()=>e.slidePrev(),children:s.jsx(o.EL,{})}),s.jsx(n.I,{onClick:()=>e.slideNext(),children:s.jsx(o.Z5,{})})]})};i()}catch(e){i(e)}})},2246:(e,t,r)=>{"use strict";r.d(t,{mn:()=>a});var i=r(7518),s=r.n(i);let a=s().div`
    position: relative;
    z-index: 0;

    .mySwiper {
        padding: 1rem 0 3rem 0;
    }
`;s().div`
    position: absolute;
    top: 50%;
    left: -22px;
    transform: translateY(-75%);
    display: grid;
    place-items: center;
    width: 55px;
    height: 55px;
    cursor: pointer;
    z-index: 200;
    border-radius: 500px;
    background-color: #ededed;

    svg {
        font-size: 30px;
        position: relative;
        left: 5px;
    }
`,s().div`
    position: absolute;
    top: 50%;
    right: -22px;
    transform: translateY(-75%);
    display: grid;
    place-items: center;
    width: 55px;
    height: 55px;
    cursor: pointer;
    z-index: 200;
    border-radius: 500px;
    background-color: #ededed;

    svg {
        font-size: 30px;
        position: relative;
        right: 5px;
    }
`},6990:(e,t,r)=>{"use strict";r.a(e,async(e,i)=>{try{r.d(t,{Z:()=>p});var s=r(997),a=r(3015),n=r(2184);r(7644),r(4700),r(5392),r(3039);var o=r(982),l=r(2246),d=r(5092),c=e([a,n,d]);[a,n,d]=c.then?(await c)():c;let p=({products:e})=>s.jsx(l.mn,{children:(0,s.jsxs)(a.Swiper,{breakpoints:{500:{slidesPerView:1},640:{slidesPerView:2,spaceBetween:20},768:{slidesPerView:3},1024:{slidesPerView:5,spaceBetween:30}},spaceBetween:30,pagination:{clickable:!1},modules:[n.Pagination,n.Navigation],className:"mySwiper",children:[e.map(e=>s.jsx(a.SwiperSlide,{children:s.jsx(o.Z,{product:e})},e.idproducto)),s.jsx(d.Z,{})]})});i()}catch(e){i(e)}})},1342:(e,t,r)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0}),function(e,t){for(var r in t)Object.defineProperty(e,r,{enumerable:!0,get:t[r]})}(t,{noSSR:function(){return o},default:function(){return l}});let i=r(167),s=i._(r(6689)),a=i._(r(4830));function n(e){return{default:(null==e?void 0:e.default)||e}}function o(e,t){delete t.webpack,delete t.modules;let r=t.loading;return()=>s.default.createElement(r,{error:null,isLoading:!0,pastDelay:!1,timedOut:!1})}function l(e,t){let r=a.default,i={loading:e=>{let{error:t,isLoading:r,pastDelay:i}=e;return null}};e instanceof Promise?i.loader=()=>e:"function"==typeof e?i.loader=e:"object"==typeof e&&(i={...i,...e}),i={...i,...t};let s=i.loader;return(i.loadableGenerated&&(i={...i,...i.loadableGenerated},delete i.loadableGenerated),"boolean"!=typeof i.ssr||i.ssr)?r({...i,loader:()=>null!=s?s().then(n):Promise.resolve(n(()=>null))}):(delete i.webpack,delete i.modules,o(r,i))}("function"==typeof t.default||"object"==typeof t.default&&null!==t.default)&&void 0===t.default.__esModule&&(Object.defineProperty(t.default,"__esModule",{value:!0}),Object.assign(t.default,t),e.exports=t.default)},4003:(e,t,r)=>{"use strict";r.r(t),r.d(t,{default:()=>o});var i=r(997),s=r(6859),a=r.n(s),n=r(7518);class o extends a(){static async getInitialProps(e){let t=new n.ServerStyleSheet,r=e.renderPage;try{e.renderPage=()=>r({enhanceApp:e=>r=>t.collectStyles(i.jsx(e,{...r}))});let s=await a().getInitialProps(e);return{...s,styles:(0,i.jsxs)(i.Fragment,{children:[s.styles,t.getStyleElement()]})}}finally{t.seal()}}render(){return(0,i.jsxs)(s.Html,{lang:"en",children:[i.jsx(s.Head,{}),(0,i.jsxs)("body",{children:[i.jsx(s.Main,{}),i.jsx(s.NextScript,{})]})]})}}},9798:(e,t,r)=>{"use strict";r.a(e,async(e,i)=>{try{r.r(t),r.d(t,{default:()=>c,getStaticProps:()=>p});var s=r(997),a=r(968),n=r.n(a),o=r(5861),l=r(9687),d=e([l]);function c({products:e,categories:t}){return(0,s.jsxs)(s.Fragment,{children:[(0,s.jsxs)(n(),{children:[s.jsx("title",{children:"Compured"}),s.jsx("meta",{name:"description",content:"Descripcion compured"}),s.jsx("meta",{name:"viewport",content:"width=device-width, initial-scale=1"}),s.jsx("link",{rel:"icon",href:"/favicon.ico"})]}),s.jsx(l.Z,{products:e,categs:t})]})}async function p(){let e=await (0,o.V)(129),t=await (0,o.Q)();return{props:{products:e[0],categories:t},revalidate:10}}l=(d.then?(await d)():d)[0],i()}catch(e){i(e)}})},5861:(e,t,r)=>{"use strict";async function i(e){let t=[1,2],r=[];for(let i=0;i<t.length;i++)r.push(await s(t[i],e));let i=new Set(r.map(e=>e.idproducto));return r=[...i].map(e=>r.find(t=>t.idproducto===e))}async function s(e,t){try{let r=await fetch(`https://api-beta.saasargentina.com/v1/productos?busqueda=&datosextras=&desde=0&cantidad=100&iddeposito=${e}&mostrarimagenes=1&idrubro=${t}&orden=nombre&iue=PuaNYqpDhRBJ7K80I8WC&S=epqr6c893g5khekkir9s0l6k6n&_=1700488253028`);if(!r.ok)throw Error(`Error en la solicitud: ${r.statusText}`);let i=await r.json();return i.resultados}catch(e){console.error(`Error en cargarProductos: ${e.message}`)}}async function a(){try{let e=await fetch("https://api-beta.saasargentina.com/v1/rubros?idrubro=0&desde=0&cantidad=100&orden=nombre&iue=PuaNYqpDhRBJ7K80I8WC&S=epqr6c893g5khekkir9s0l6k6n&_=1700488253028");if(!e.ok)throw Error(`Error en la solicitud: ${e.statusText}`);let t=await e.json();return t}catch(e){console.error(`Error en cargarProductos: ${e.message}`)}}async function n(e){try{let t=await fetch(`https://api-beta.saasargentina.com/v1/rubros?idrubro=${e}&desde=0&cantidad=100&orden=nombre&iue=PuaNYqpDhRBJ7K80I8WC&S=epqr6c893g5khekkir9s0l6k6n&_=1700488253028`);if(!t.ok)throw Error(`Error en la solicitud: ${t.statusText}`);let r=await t.json(),i=r.map(e=>({idrubro:e.idrubro,nombre:e.nombre}));return i}catch(e){console.error(`Error en cargarProductos: ${e.message}`)}}async function o(){try{let e=await a(),t=[];for(let r of e){let e=await n(r.idrubro);t.push({parent:r,children:[...e]})}return t}catch(e){throw console.error(`Error in getAllCategoriesAndSubCategories: ${e.message}`),e}}r.d(t,{Q:()=>o,V:()=>i})},4700:()=>{},3039:()=>{},5392:()=>{},7644:()=>{},5244:(e,t)=>{"use strict";var r;Object.defineProperty(t,"x",{enumerable:!0,get:function(){return r}}),function(e){e.PAGES="PAGES",e.PAGES_API="PAGES_API",e.APP_PAGE="APP_PAGE",e.APP_ROUTE="APP_ROUTE"}(r||(r={}))},4830:(e,t,r)=>{"use strict";e.exports=r(7093).vendored.contexts.Loadable},5152:(e,t,r)=>{e.exports=r(1342)},2785:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/pages.runtime.prod.js")},968:e=>{"use strict";e.exports=require("next/head")},6689:e=>{"use strict";e.exports=require("react")},6405:e=>{"use strict";e.exports=require("react-dom")},997:e=>{"use strict";e.exports=require("react/jsx-runtime")},7518:e=>{"use strict";e.exports=require("styled-components")},6197:e=>{"use strict";e.exports=import("framer-motion")},2184:e=>{"use strict";e.exports=import("swiper/modules")},3015:e=>{"use strict";e.exports=import("swiper/react")},7147:e=>{"use strict";e.exports=require("fs")},1017:e=>{"use strict";e.exports=require("path")},2781:e=>{"use strict";e.exports=require("stream")},9796:e=>{"use strict";e.exports=require("zlib")}};var t=require("../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),i=t.X(0,[428,571,859,488],()=>r(5819));module.exports=i})();