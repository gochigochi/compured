"use strict";(()=>{var e={};e.id=777,e.ids=[777],e.modules={5638:(e,t,r)=>{r.r(t),r.d(t,{config:()=>z,default:()=>q,getServerSideProps:()=>k,getStaticPaths:()=>y,getStaticProps:()=>_,reportWebVitals:()=>M,routeModule:()=>D,unstable_getServerProps:()=>A,unstable_getServerSideProps:()=>C,unstable_getStaticParams:()=>Z,unstable_getStaticPaths:()=>V,unstable_getStaticProps:()=>N});var i={};r.r(i),r.d(i,{default:()=>j,getStaticPaths:()=>w,getStaticProps:()=>P});var a=r(7093),s=r(5244),o=r(1323),n=r(4003),p=r(5401),l=r(997),d=r(968),c=r.n(d),u=r(5861),x=r(6689),g=r(6537),h=r(982),m=r(6971),f=r(7518),v=r.n(f);let b=v().section`
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    margin: 5px 0;
    gap: 25px;
    min-height: 500px;
`,S=({products:e,categs:t})=>{let{setCategories:r}=(0,g.u)();return(0,x.useEffect)(()=>r(t),[]),l.jsx(m.Mp,{children:l.jsx(m.Nh,{children:l.jsx(b,{children:e?.map(e=>l.jsx(h.Z,{product:e}))})})})},j=({products:e,categories:t})=>(0,l.jsxs)(l.Fragment,{children:[(0,l.jsxs)(c(),{children:[l.jsx("title",{children:"Compured"}),l.jsx("meta",{name:"description",content:"Descripcion compured"}),l.jsx("meta",{name:"viewport",content:"width=device-width, initial-scale=1"}),l.jsx("link",{rel:"icon",href:"/favicon.ico"})]}),l.jsx(S,{products:e,categs:t})]});async function P({params:e}){let t=e.category,r=t.slice(t.indexOf("=")+1,t.indexOf("&")),i=await (0,u.V)(r),a=await (0,u.Q)();return{props:{products:i[0],categories:a},revalidate:10}}async function w(){return{paths:[],fallback:"blocking"}}let q=(0,o.l)(i,"default"),_=(0,o.l)(i,"getStaticProps"),y=(0,o.l)(i,"getStaticPaths"),k=(0,o.l)(i,"getServerSideProps"),z=(0,o.l)(i,"config"),M=(0,o.l)(i,"reportWebVitals"),N=(0,o.l)(i,"unstable_getStaticProps"),V=(0,o.l)(i,"unstable_getStaticPaths"),Z=(0,o.l)(i,"unstable_getStaticParams"),A=(0,o.l)(i,"unstable_getServerProps"),C=(0,o.l)(i,"unstable_getServerSideProps"),D=new a.PagesRouteModule({definition:{kind:s.x.PAGES,page:"/productos/[category]",pathname:"/productos/[category]",bundlePath:"",filename:""},components:{App:p.default,Document:n.default},userland:i})},6971:(e,t,r)=>{r.d(t,{Ku:()=>p,Mp:()=>s,NZ:()=>n,Nh:()=>o});var i=r(7518),a=r.n(i);let s=a().div`
    position: relative;
    padding: 30px 12px;
`,o=a().div`
    max-width: var(--inner-max-width);
    margin: 0 auto;
    padding: 0 20px;
`,n=a().h2`
    font-size: 2rem;
`,p=a().p``},982:(e,t,r)=>{r.d(t,{Z:()=>m});var i=r(997),a=r(7518),s=r.n(a),o=r(1664),n=r.n(o),p=r(5675),l=r.n(p);let d=s()(n())`
    width: 100%;
    border-radius: 8px;
    height: 330px;
    display: inline-block;
    padding: 3px 3px 14px;
    box-shadow: var(--light-shadow);
    border: 1px solid rgba(25, 141, 179, 0.1);
`,c=s().div`
    position: relative;
    width: 100%;
    height: 150px;
`,u=s().div`
    position: relative;
    margin-top: 15px;
    padding: 0 15px;

    &:after {
        content: "";
        position: absolute;
        height: 1px;
        width: calc(100% - 15px);
        top: -10px;
        left: 50%;
        transform: translateX(-50%);
        background-color: var(--soft-gray);
    }
`,x=s()(l())`
    object-fit: contain;
`,g=s().p`
    white-space: nowrap; 
    overflow: hidden;
    text-overflow: ellipsis;
    margin-bottom: 15px;
`,h=s().p`
    font-size: 1.5rem;
    margin-bottom: 15px;
`,Text=s().p`
    color: var(--text-light);
    font-size: 0.8em;
`,m=({product:e})=>(0,i.jsxs)(d,{href:`/producto/${e.idproducto}`,children:[i.jsx(c,{children:i.jsx(x,{src:e.imagen_url,alt:e.nombre,fill:!0})}),(0,i.jsxs)(u,{children:[i.jsx(g,{children:e.nombre}),(0,i.jsxs)(h,{children:["$",e.preciofinal]}),i.jsx(Text,{children:e.nombre})]})]})},2785:e=>{e.exports=require("next/dist/compiled/next-server/pages.runtime.prod.js")},968:e=>{e.exports=require("next/head")},6689:e=>{e.exports=require("react")},6405:e=>{e.exports=require("react-dom")},997:e=>{e.exports=require("react/jsx-runtime")},7518:e=>{e.exports=require("styled-components")},7147:e=>{e.exports=require("fs")},1017:e=>{e.exports=require("path")},2781:e=>{e.exports=require("stream")},9796:e=>{e.exports=require("zlib")}};var t=require("../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),i=t.X(0,[428,571,859,158],()=>r(5638));module.exports=i})();