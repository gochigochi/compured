"use strict";(()=>{var e={};e.id=777,e.ids=[777,888,660],e.modules={1323:(e,t)=>{Object.defineProperty(t,"l",{enumerable:!0,get:function(){return function e(t,r){return r in t?t[r]:"then"in t&&"function"==typeof t.then?t.then(t=>e(t,r)):"function"==typeof t&&"default"===r?t:void 0}}})},3950:(e,t,r)=>{r.r(t),r.d(t,{config:()=>$,default:()=>E,getServerSideProps:()=>A,getStaticPaths:()=>_,getStaticProps:()=>q,reportWebVitals:()=>C,routeModule:()=>D,unstable_getServerProps:()=>N,unstable_getServerSideProps:()=>O,unstable_getStaticParams:()=>G,unstable_getStaticPaths:()=>R,unstable_getStaticProps:()=>I});var a={};r.r(a),r.d(a,{default:()=>w,getStaticPaths:()=>k,getStaticProps:()=>y});var o=r(7093),i=r(5244),n=r(1323),s=r(4003),c=r(2488),l=r(997),d=r(968),u=r.n(d),p=r(5861),h=r(6689),g=r(6537),x=r(982),m=r(6971),f=r(7518),b=r.n(f);let P=b().section`
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    margin: 5px 0;
    gap: 25px;
    min-height: 500px;
`,S=b().div`
    width: 100%;
    height: 80vh;
    display: grid;
    place-items: center;
`,j=({products:e,categs:t})=>{let{setCategories:r}=(0,g.u)();return((0,h.useEffect)(()=>r(t),[]),0===e.length)?l.jsx(m.Mp,{children:l.jsx(S,{children:"No se encontraron products. Intente con t\xe9rminos m\xe1s sencillos."})}):l.jsx(m.Mp,{children:l.jsx(m.Nh,{children:l.jsx(P,{children:e?.map(e=>l.jsx(x.Z,{product:e},e.idproducto))})})})},v=async e=>{let t=`https://api-alfa.saasargentina.com/v0.2/productos?desde=0&cantidad=100&orden=nombre&mostrarimagenes=1&iue=PuaNYqpDhRBJ7K80I8WC&busqueda=${e}`;try{let e=await fetch(t);if(!e.ok)throw Error(`Error en la solicitud: ${e.statusText}`);let r=await e.json();return r.resultados}catch(e){console.error("Error:",e.message)}},w=({products:e,categories:t})=>(0,l.jsxs)(l.Fragment,{children:[(0,l.jsxs)(u(),{children:[l.jsx("title",{children:"Compured"}),l.jsx("meta",{name:"description",content:"Descripcion compured"}),l.jsx("meta",{name:"viewport",content:"width=device-width, initial-scale=1"}),l.jsx("link",{rel:"icon",href:"/favicon.ico"})]}),l.jsx(j,{products:e,categs:t})]});async function y({params:e}){let t=e.category,r=await (0,p.Q)();if(t.includes("id")){let e=t.slice(t.indexOf("=")+1,t.indexOf("&")),a=await (0,p.V)(e);return{props:{products:a[0],categories:r},revalidate:10}}if(t.includes("search")){let e=t.slice(t.indexOf("=")+1),a=await v(e);return{props:{products:a,categories:r},revalidate:10}}}async function k(){return{paths:[],fallback:"blocking"}}let E=(0,n.l)(a,"default"),q=(0,n.l)(a,"getStaticProps"),_=(0,n.l)(a,"getStaticPaths"),A=(0,n.l)(a,"getServerSideProps"),$=(0,n.l)(a,"config"),C=(0,n.l)(a,"reportWebVitals"),I=(0,n.l)(a,"unstable_getStaticProps"),R=(0,n.l)(a,"unstable_getStaticPaths"),G=(0,n.l)(a,"unstable_getStaticParams"),N=(0,n.l)(a,"unstable_getServerProps"),O=(0,n.l)(a,"unstable_getServerSideProps"),D=new o.PagesRouteModule({definition:{kind:i.x.PAGES,page:"/productos/[category]",pathname:"/productos/[category]",bundlePath:"",filename:""},components:{App:c.default,Document:s.default},userland:a})},982:(e,t,r)=>{r.d(t,{Z:()=>m});var a=r(997),o=r(1163),i=r(2847),n=r(7518),s=r.n(n),c=r(5675),l=r.n(c);let d=s().button`
    width: 100%;
    border-radius: 8px;
    height: 330px;
    display: inline-block;
    padding: 3px 3px 14px;
    box-shadow: var(--light-shadow);
    border: 1px solid rgba(25, 141, 179, 0.1);
`,u=s().div`
    position: relative;
    width: 100%;
    height: 150px;
`,p=s().div`
    position: relative;
    margin-top: 15px;
    padding: 0 15px;

    &:after {
        content: "";
        position: absolute;
        height: 1px;
        width: calc(100% - 15px);
        top: -10px;
        left: 50%;
        transform: translateX(-50%);
        background-color: var(--soft-gray);
    }
`,h=s()(l())`
    object-fit: contain;
`,g=s().p`
    white-space: nowrap; 
    overflow: hidden;
    text-overflow: ellipsis;
    margin-bottom: 15px;
`,x=s().p`
    font-size: 1.5rem;
    margin-bottom: 15px;
`,Text=s().p`
    color: var(--text-light);
    font-size: 0.8em;
`,m=({product:e})=>{let t=(0,o.useRouter)(),r=(e,r)=>{let a=(0,i.C)(e);t.push(`/producto/${r}`,`/producto/id=${r}&${a}`)};return(0,a.jsxs)(d,{onClick:()=>r(e.nombre,e.idproducto),children:[a.jsx(u,{children:a.jsx(h,{src:e.imagen_url,alt:e.nombre,fill:!0})}),(0,a.jsxs)(p,{children:[a.jsx(g,{children:e.nombre}),(0,a.jsxs)(x,{children:["$",e.preciofinal]}),a.jsx(Text,{children:e.nombre})]})]})}},4003:(e,t,r)=>{r.r(t),r.d(t,{default:()=>s});var a=r(997),o=r(6859),i=r.n(o),n=r(7518);class s extends i(){static async getInitialProps(e){let t=new n.ServerStyleSheet,r=e.renderPage;try{e.renderPage=()=>r({enhanceApp:e=>r=>t.collectStyles(a.jsx(e,{...r}))});let o=await i().getInitialProps(e);return{...o,styles:(0,a.jsxs)(a.Fragment,{children:[o.styles,t.getStyleElement()]})}}finally{t.seal()}}render(){return(0,a.jsxs)(o.Html,{lang:"en",children:[a.jsx(o.Head,{}),(0,a.jsxs)("body",{children:[a.jsx(o.Main,{}),a.jsx(o.NextScript,{})]})]})}}},5861:(e,t,r)=>{async function a(e){let t=[1,2],r=[];for(let a=0;a<t.length;a++)r.push(await o(t[a],e));let a=new Set(r.map(e=>e.idproducto));return r=[...a].map(e=>r.find(t=>t.idproducto===e))}async function o(e,t){try{let r=await fetch(`https://api-beta.saasargentina.com/v1/productos?busqueda=&datosextras=&desde=0&cantidad=100&iddeposito=${e}&mostrarimagenes=1&idrubro=${t}&orden=nombre&iue=PuaNYqpDhRBJ7K80I8WC&S=epqr6c893g5khekkir9s0l6k6n&_=1700488253028`);if(!r.ok)throw Error(`Error en la solicitud: ${r.statusText}`);let a=await r.json();return a.resultados}catch(e){console.error(`Error en cargarProductos: ${e.message}`)}}async function i(){try{let e=await fetch("https://api-beta.saasargentina.com/v1/rubros?idrubro=0&desde=0&cantidad=100&orden=nombre&iue=PuaNYqpDhRBJ7K80I8WC&S=epqr6c893g5khekkir9s0l6k6n&_=1700488253028");if(!e.ok)throw Error(`Error en la solicitud: ${e.statusText}`);let t=await e.json();return t}catch(e){console.error(`Error en cargarProductos: ${e.message}`)}}async function n(e){try{let t=await fetch(`https://api-beta.saasargentina.com/v1/rubros?idrubro=${e}&desde=0&cantidad=100&orden=nombre&iue=PuaNYqpDhRBJ7K80I8WC&S=epqr6c893g5khekkir9s0l6k6n&_=1700488253028`);if(!t.ok)throw Error(`Error en la solicitud: ${t.statusText}`);let r=await t.json(),a=r.map(e=>({idrubro:e.idrubro,nombre:e.nombre}));return a}catch(e){console.error(`Error en cargarProductos: ${e.message}`)}}async function s(){try{let e=await i(),t=[];for(let r of e){let e=await n(r.idrubro);t.push({parent:r,children:[...e]})}return t}catch(e){throw console.error(`Error in getAllCategoriesAndSubCategories: ${e.message}`),e}}r.d(t,{Q:()=>s,V:()=>a})},5244:(e,t)=>{var r;Object.defineProperty(t,"x",{enumerable:!0,get:function(){return r}}),function(e){e.PAGES="PAGES",e.PAGES_API="PAGES_API",e.APP_PAGE="APP_PAGE",e.APP_ROUTE="APP_ROUTE"}(r||(r={}))},2785:e=>{e.exports=require("next/dist/compiled/next-server/pages.runtime.prod.js")},968:e=>{e.exports=require("next/head")},6689:e=>{e.exports=require("react")},6405:e=>{e.exports=require("react-dom")},997:e=>{e.exports=require("react/jsx-runtime")},7518:e=>{e.exports=require("styled-components")},7147:e=>{e.exports=require("fs")},1017:e=>{e.exports=require("path")},2781:e=>{e.exports=require("stream")},9796:e=>{e.exports=require("zlib")}};var t=require("../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),a=t.X(0,[428,571,859,488],()=>r(3950));module.exports=a})();