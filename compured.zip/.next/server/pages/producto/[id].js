(()=>{var e={};e.id=335,e.ids=[335,888,660],e.modules={1323:(e,t)=>{"use strict";Object.defineProperty(t,"l",{enumerable:!0,get:function(){return function e(t,r){return r in t?t[r]:"then"in t&&"function"==typeof t.then?t.then(t=>e(t,r)):"function"==typeof t&&"default"===r?t:void 0}}})},2046:(e,t,r)=>{"use strict";r.a(e,async(e,i)=>{try{r.r(t),r.d(t,{config:()=>h,default:()=>p,getServerSideProps:()=>g,getStaticPaths:()=>x,getStaticProps:()=>u,reportWebVitals:()=>m,routeModule:()=>y,unstable_getServerProps:()=>j,unstable_getServerSideProps:()=>w,unstable_getStaticParams:()=>b,unstable_getStaticPaths:()=>v,unstable_getStaticProps:()=>f});var s=r(7093),o=r(5244),a=r(1323),n=r(4003),l=r(2488),d=r(2705),c=e([d]);d=(c.then?(await c)():c)[0];let p=(0,a.l)(d,"default"),u=(0,a.l)(d,"getStaticProps"),x=(0,a.l)(d,"getStaticPaths"),g=(0,a.l)(d,"getServerSideProps"),h=(0,a.l)(d,"config"),m=(0,a.l)(d,"reportWebVitals"),f=(0,a.l)(d,"unstable_getStaticProps"),v=(0,a.l)(d,"unstable_getStaticPaths"),b=(0,a.l)(d,"unstable_getStaticParams"),j=(0,a.l)(d,"unstable_getServerProps"),w=(0,a.l)(d,"unstable_getServerSideProps"),y=new s.PagesRouteModule({definition:{kind:o.x.PAGES,page:"/producto/[id]",pathname:"/producto/[id]",bundlePath:"",filename:""},components:{App:l.default,Document:n.default},userland:d});i()}catch(e){i(e)}})},3618:(e,t,r)=>{"use strict";r.d(t,{Z:()=>n});var i=r(997),s=r(7518),o=r.n(s);let a=o().button`
    background-color: ${({dis:e})=>e?"var(--dark-blue)":"var(--blue)"};
    border-radius: 25px;
    padding: var(--button-padding);
    color: #fff;
    cursor: ${({dis:e})=>e?"default":"pointer"};
    transition: all .2s;

    &:hover {
        ${({dis:e})=>!e&&"opacity: .8;"}
    }
`,n=({children:e,onClick:t=()=>{},disabled:r=!1})=>i.jsx(a,{onClick:t,disabled:r,dis:r,children:e})},982:(e,t,r)=>{"use strict";r.d(t,{Z:()=>m});var i=r(997),s=r(1163),o=r(2847),a=r(7518),n=r.n(a),l=r(5675),d=r.n(l);let c=n().button`
    width: 100%;
    border-radius: 8px;
    height: 330px;
    display: inline-block;
    padding: 3px 3px 14px;
    box-shadow: var(--light-shadow);
    border: 1px solid rgba(25, 141, 179, 0.1);
`,p=n().div`
    position: relative;
    width: 100%;
    height: 150px;
`,u=n().div`
    position: relative;
    margin-top: 15px;
    padding: 0 15px;

    &:after {
        content: "";
        position: absolute;
        height: 1px;
        width: calc(100% - 15px);
        top: -10px;
        left: 50%;
        transform: translateX(-50%);
        background-color: var(--soft-gray);
    }
`,x=n()(d())`
    object-fit: contain;
`,g=n().p`
    white-space: nowrap; 
    overflow: hidden;
    text-overflow: ellipsis;
    margin-bottom: 15px;
`,h=n().p`
    font-size: 1.5rem;
    margin-bottom: 15px;
`,Text=n().p`
    color: var(--text-light);
    font-size: 0.8em;
`,m=({product:e})=>{let t=(0,s.useRouter)(),r=(e,r)=>{let i=(0,o.C)(e);t.push(`/producto/${r}`,`/producto/id=${r}&${i}`)};return(0,i.jsxs)(c,{onClick:()=>r(e.nombre,e.idproducto),children:[i.jsx(p,{children:i.jsx(x,{src:e.imagen_url,alt:e.nombre,fill:!0})}),(0,i.jsxs)(u,{children:[i.jsx(g,{children:e.nombre}),(0,i.jsxs)(h,{children:["$",e.preciofinal]}),i.jsx(Text,{children:e.nombre})]})]})}},4952:(e,t,r)=>{"use strict";r.d(t,{Bc:()=>x,Dx:()=>n,Kc:()=>o,M4:()=>g,PO:()=>a,YD:()=>c,dk:()=>d,iz:()=>u,pG:()=>p,tA:()=>l});var i=r(7518),s=r.n(i);let o=s().article`
    display: grid;
    grid-template-columns: 1fr 1fr;
    column-gap: 2rem;
    margin: 35px 0 85px 0;
`,a=s().div``,n=s().h1`
    font-size: 2.5rem;
`,l=s().p`
    font-size: 2.5rem;
    font-weight: 400;
    margin-top: 30px;
`,d=s().p`
    margin-top: 30px;
`,c=s().div`
    display: flex;
    margin: 35px 0 45px 0;
`,p=s().div`
    border: 1px solid var(--blue);
    border-radius: 25px;
    padding: var(--button-padding);
    margin-right: 15px;
    position: relative;
`,u=s().div`
    background-color: var(--soft-gray);
    height: 1px;
    margin: 35px 0;
`,x=s().p``,g=s().p`
    font-size: .8rem;
`},7293:(e,t,r)=>{"use strict";r.a(e,async(e,i)=>{try{r.d(t,{Z:()=>w});var s=r(997),o=r(5152),a=r.n(o),n=r(6689),l=r(6537),d=r(3618),c=r(701),p=r(8132),u=r(1475),x=r(7224),g=r(9548),h=r(6990),m=r(2995),f=r(6971),v=r(4952),b=e([c,h]);[c,h]=b.then?(await b)():b;let j=a()(async()=>{},{loadableGenerated:{modules:["..\\components\\product_detail\\ProductDetail.jsx -> ../toast/Toast"]},ssr:!1}),w=({product:e,categs:t,featured:r})=>{let{setCategories:i}=(0,l.u)(),{addItem:o}=(0,m.i)(),[a,b]=(0,n.useState)(1),[w,y]=(0,n.useState)(!1),[P,k]=(0,n.useState)();return(0,n.useEffect)(()=>i(t),[]),(0,s.jsxs)(f.Mp,{bgcolor:"#F9FAFB",children:[(0,s.jsxs)(f.Nh,{children:[(0,s.jsxs)(v.Kc,{children:[s.jsx(c.Z,{images:e.archivos}),(0,s.jsxs)(v.PO,{children:[s.jsx(v.Dx,{children:e?.nombre}),(0,s.jsxs)(v.tA,{children:["$",e?.preciofinal]}),s.jsx(v.dk,{children:e?.nombre}),(0,s.jsxs)(v.YD,{children:[(0,s.jsxs)(v.pG,{children:[s.jsx("span",{children:"Cantidad"}),s.jsx(g.Z,{stock:e.stockactual,setQty:b}),s.jsx(u.Z,{stock:e.productsStock})]}),s.jsx(d.Z,{onClick:()=>{let t=o(e,a);y(!0),k({success:t.success,msg:t.msg})},disabled:w,children:"Agregar al carrito"})]}),s.jsx(v.iz,{}),s.jsx(p.Z,{}),s.jsx(x.Z,{}),s.jsx(v.iz,{}),s.jsx(v.Bc,{children:"Devoluciones"}),s.jsx(v.M4,{children:"Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur."})]})]}),s.jsx(h.Z,{products:r})]}),w?s.jsx(j,{msg:P.msg,success:P.success,time:2500,setShowToast:y}):null]})};i()}catch(e){i(e)}})},8132:(e,t,r)=>{"use strict";r.d(t,{Z:()=>m});var i=r(997),s=r(5675),o=r.n(s),a=r(7518),n=r.n(a);let l=n().div``,d=n().p``,c=n().table`
    table-layout: auto;
    border-collapse: collapse;
`,p=n().tr`

`,u=n().td`
    font-size: .8rem;
    color: var(--text-light);
    padding-right: 50px;
`,x=n().div`
    position: relative;
    width: 40px;
    height: 50px;
    display: grid;
    place-items: center;
`,g=n()(o())`
    object-fit: contain;
`,h=[{text:"Con el respaldo de",logos:["https://drive.google.com/uc?export=view&id=1ee819aLwME2qr-398rlVmZbFuxtFOR7O","https://drive.google.com/uc?export=view&id=1yhHhZtJGhdeDkqq_qAKyiQ9hC-EgEsQc"]},{text:"D\xe9bito",logos:["https://drive.google.com/uc?export=view&id=1OXkQ7Vp-6Z3c5WwJAdHcOVNLOOvuaZj8","https://drive.google.com/uc?export=view&id=1ElOsLWi6PTjzhO6xcQqM9FHBZlOCeQsj","https://drive.google.com/uc?export=view&id=15ZZ0N29xFkD7xxuajC2S4E1S-jQCguQG","https://drive.google.com/uc?export=view&id=1nsy1oERD4dq10m4UQYlurK8kEhR8rq6l"]},{text:"Cr\xe9dito",logos:["https://drive.google.com/uc?export=view&id=1Ep3bQ9jcfEEATqkiOfzpXcZFtli2bURb","https://drive.google.com/uc?export=view&id=1EFUG0jLzaw2HyQ5ha3h38jsPSgbiDqaY","https://drive.google.com/uc?export=view&id=1UjhLib1eAq5vvnebBW-e1HkGlU88jixI","https://drive.google.com/uc?export=view&id=1dR0vroSkTOgqx8boLGVD0XQSXBk02kjv"]},{text:"Efectivo",logos:["https://drive.google.com/uc?export=view&id=1-P46yTG5ZT-PtgiqDfAI-dVA2MPVxBT5","https://drive.google.com/uc?export=view&id=1j8GV9wjaETW5OWFDLXmHRHQ05QOkEhy-"]}],m=()=>(0,i.jsxs)(l,{children:[i.jsx(d,{children:"M\xe9todos de pago"}),i.jsx(c,{children:i.jsx("tbody",{children:h.map(e=>(0,i.jsxs)(p,{children:[i.jsx(u,{children:e.text}),e.logos.map(e=>i.jsx(u,{children:i.jsx(x,{children:i.jsx(g,{src:e,alt:" ",fill:!0})})},e))]},e.text))})})]})},9548:(e,t,r)=>{"use strict";r.d(t,{Z:()=>n});var i=r(997),s=r(7518),o=r.n(s);let a=o().select`
    border: none;
    outline: none;
    font-size: 1rem;
    margin-left: 15px;
    cursor: pointer;
`,n=({stock:e,setQty:t})=>{let r=Array.from({length:parseInt(e)},(e,t)=>t+1);return i.jsx(a,{name:"qty",id:"qty",onChange:e=>t(parseInt(e.target.value)),children:r.map(e=>i.jsx("option",{value:e,children:e},e))})}},7224:(e,t,r)=>{"use strict";r.d(t,{Z:()=>v});var i=r(997),s=r(7518),o=r.n(s),a=r(5675),n=r.n(a);let l=o().div`
    margin-top: 50px;
    border-radius: 12px;
    border: 1px solid var(--gray-bg);
`,d=o().div`
    background-color: var(--gray-bg);
    display: flex;
    justify-content: space-between;
    border-radius: 12px 12px 0 0;
`,c=o().p`
    display: grid;
    place-items: center;
    padding: 0 15px;
`,p=o()(n())`
    object-fit: contain;
`,u=o().div`
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    grid-gap: 25px;
    padding: 20px;
`,x=o().div`
    display: grid;
    gird-template-rows: repeat(2, 1fr);
    row-gap: 12px;
`,g=o().label`
    color: var(--text-light);
    font-size: .9rem;
`,h=o().input`
    border-radius: 25px;
    border: 2px solid var(--gray-bg);
    width: 125px;
    height: 32px;
    font-size: 1.5rem;
    padding: 0 15px;
    text-align: center;
`,m=o().p`
    color: var(--text-light);
    font-size: .9rem;
    border-bottom: 1px solid var(--gray-bg);
`,f=o().p`
    height: 32px;
    font-size: 1.5rem;
    text-align: right;
`,v=()=>(0,i.jsxs)(l,{children:[(0,i.jsxs)(d,{children:[i.jsx(c,{children:"Env\xedos"}),i.jsx(p,{src:"https://drive.google.com/uc?export=view&id=1Sc6QkoPjD5E3s7XG9yAcnXqTN_TI1uaw",width:150,height:50})]}),(0,i.jsxs)(u,{children:[(0,i.jsxs)(x,{children:[i.jsx(g,{children:"Ingres\xe1 tu c\xf3digo postal"}),i.jsx(h,{id:"zip",name:"zip",type:"text",pattern:"[0-9]*"})]}),(0,i.jsxs)(x,{children:[i.jsx(m,{children:"Costo de env\xedo"}),i.jsx(f,{children:"$15000"})]})]})]})},1475:(e,t,r)=>{"use strict";r.d(t,{Z:()=>n});var i=r(997),s=r(7518),o=r.n(s);let a=o().p`
    position: absolute;
    bottom: -15px;
    left: 15px;
    width: 100%;
    color: var(--text-light);
    font-size: .6rem;

    span {
        margin-right: 5px;
    }
`,n=({stock:e})=>(0,i.jsxs)(a,{children:[i.jsx("span",{children:e[0].stock>0?`Casa Matriz (${e[0].stock})`:null}),i.jsx("span",{children:e[1].stock>0?`Sucursal (${e[1].stock})`:null})]})},8073:(e,t,r)=>{"use strict";r.d(t,{I:()=>a,h:()=>o});var i=r(7518),s=r.n(i);let o=s().div`
    position: absolute;
    top: 50%;
    left: -22px;
    transform: translateY(-75%);
    display: grid;
    place-items: center;
    width: 55px;
    height: 55px;
    cursor: pointer;
    z-index: 200;
    border-radius: 500px;
    background-color: #ededed;
    opacity: .5;
    transition: opacity .2s;

    svg {
        font-size: 30px;
        position: relative;
        left: 5px;

        path {
            color: var(--blue);
        }
    }

    &:hover {
        opacity: 1;
    }
`,a=s().div`
    position: absolute;
    top: 50%;
    right: -22px;
    transform: translateY(-75%);
    display: grid;
    place-items: center;
    width: 55px;
    height: 55px;
    cursor: pointer;
    z-index: 200;
    border-radius: 500px;
    background-color: #ededed;
    opacity: .5;
    transition: opacity .2s;

    svg {
        font-size: 30px;
        position: relative;
        right: 5px;

        path {
            color: var(--blue);
        }
    }

    &:hover {
        opacity: 1;
    }
`},5092:(e,t,r)=>{"use strict";r.a(e,async(e,i)=>{try{r.d(t,{Z:()=>d});var s=r(997),o=r(3015),a=r(8073),n=r(6739),l=e([o]);o=(l.then?(await l)():l)[0];let d=()=>{let e=(0,o.useSwiper)();return(0,s.jsxs)(s.Fragment,{children:[s.jsx(a.h,{onClick:()=>e.slidePrev(),children:s.jsx(n.EL,{})}),s.jsx(a.I,{onClick:()=>e.slideNext(),children:s.jsx(n.Z5,{})})]})};i()}catch(e){i(e)}})},3783:(e,t,r)=>{"use strict";r.d(t,{E:()=>l,m:()=>n});var i=r(5675),s=r.n(i),o=r(7518),a=r.n(o);let n=a().div`
    position: relative;

    .mySwiper {
        background-color: #fff;
        border-radius: 12px;
        width: 500px;
        height: 380px;
        box-shadow: var(--light-shadow);
        padding: 1rem 0 3rem 0;
    }
`,l=a()(s())`
    object-fit: contain;
    // left: 50% !important;
    top: 50% !important;
    height: 90% !important;
    transform: translateY(-50%) !important;
`},701:(e,t,r)=>{"use strict";r.a(e,async(e,i)=>{try{r.d(t,{Z:()=>c});var s=r(997),o=r(3015),a=r(2184);r(7644),r(5392);var n=r(3783),l=r(5092),d=e([o,a,l]);[o,a,l]=d.then?(await d)():d;let c=({images:e})=>s.jsx(n.m,{children:(0,s.jsxs)(o.Swiper,{pagination:{dynamicBullets:!0},loop:!0,modules:[a.Pagination],className:"mySwiper",children:[e.map(e=>s.jsx(o.SwiperSlide,{children:s.jsx(n.E,{src:e.imagen,alt:"",fill:!0})},e.imagen)),s.jsx(l.Z,{})]})});i()}catch(e){i(e)}})},2246:(e,t,r)=>{"use strict";r.d(t,{mn:()=>o});var i=r(7518),s=r.n(i);let o=s().div`
    position: relative;
    z-index: 0;

    .mySwiper {
        padding: 1rem 0 3rem 0;
    }
`;s().div`
    position: absolute;
    top: 50%;
    left: -22px;
    transform: translateY(-75%);
    display: grid;
    place-items: center;
    width: 55px;
    height: 55px;
    cursor: pointer;
    z-index: 200;
    border-radius: 500px;
    background-color: #ededed;

    svg {
        font-size: 30px;
        position: relative;
        left: 5px;
    }
`,s().div`
    position: absolute;
    top: 50%;
    right: -22px;
    transform: translateY(-75%);
    display: grid;
    place-items: center;
    width: 55px;
    height: 55px;
    cursor: pointer;
    z-index: 200;
    border-radius: 500px;
    background-color: #ededed;

    svg {
        font-size: 30px;
        position: relative;
        right: 5px;
    }
`},6990:(e,t,r)=>{"use strict";r.a(e,async(e,i)=>{try{r.d(t,{Z:()=>p});var s=r(997),o=r(3015),a=r(2184);r(7644),r(4700),r(5392),r(3039);var n=r(982),l=r(2246),d=r(5092),c=e([o,a,d]);[o,a,d]=c.then?(await c)():c;let p=({products:e})=>s.jsx(l.mn,{children:(0,s.jsxs)(o.Swiper,{breakpoints:{500:{slidesPerView:1},640:{slidesPerView:2,spaceBetween:20},768:{slidesPerView:3},1024:{slidesPerView:5,spaceBetween:30}},spaceBetween:30,pagination:{clickable:!1},modules:[a.Pagination,a.Navigation],className:"mySwiper",children:[e.map(e=>s.jsx(o.SwiperSlide,{children:s.jsx(n.Z,{product:e})},e.idproducto)),s.jsx(d.Z,{})]})});i()}catch(e){i(e)}})},1342:(e,t,r)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0}),function(e,t){for(var r in t)Object.defineProperty(e,r,{enumerable:!0,get:t[r]})}(t,{noSSR:function(){return n},default:function(){return l}});let i=r(167),s=i._(r(6689)),o=i._(r(4830));function a(e){return{default:(null==e?void 0:e.default)||e}}function n(e,t){delete t.webpack,delete t.modules;let r=t.loading;return()=>s.default.createElement(r,{error:null,isLoading:!0,pastDelay:!1,timedOut:!1})}function l(e,t){let r=o.default,i={loading:e=>{let{error:t,isLoading:r,pastDelay:i}=e;return null}};e instanceof Promise?i.loader=()=>e:"function"==typeof e?i.loader=e:"object"==typeof e&&(i={...i,...e}),i={...i,...t};let s=i.loader;return(i.loadableGenerated&&(i={...i,...i.loadableGenerated},delete i.loadableGenerated),"boolean"!=typeof i.ssr||i.ssr)?r({...i,loader:()=>null!=s?s().then(a):Promise.resolve(a(()=>null))}):(delete i.webpack,delete i.modules,n(r,i))}("function"==typeof t.default||"object"==typeof t.default&&null!==t.default)&&void 0===t.default.__esModule&&(Object.defineProperty(t.default,"__esModule",{value:!0}),Object.assign(t.default,t),e.exports=t.default)},4003:(e,t,r)=>{"use strict";r.r(t),r.d(t,{default:()=>n});var i=r(997),s=r(6859),o=r.n(s),a=r(7518);class n extends o(){static async getInitialProps(e){let t=new a.ServerStyleSheet,r=e.renderPage;try{e.renderPage=()=>r({enhanceApp:e=>r=>t.collectStyles(i.jsx(e,{...r}))});let s=await o().getInitialProps(e);return{...s,styles:(0,i.jsxs)(i.Fragment,{children:[s.styles,t.getStyleElement()]})}}finally{t.seal()}}render(){return(0,i.jsxs)(s.Html,{lang:"en",children:[i.jsx(s.Head,{}),(0,i.jsxs)("body",{children:[i.jsx(s.Main,{}),i.jsx(s.NextScript,{})]})]})}}},2705:(e,t,r)=>{"use strict";r.a(e,async(e,i)=>{try{r.r(t),r.d(t,{default:()=>x,getStaticPaths:()=>u,getStaticProps:()=>p});var s=r(997),o=r(968),a=r.n(o),n=r(7293),l=r(5861),d=r(6729),c=e([n]);n=(c.then?(await c)():c)[0];let x=({product:e,categories:t,featured:r})=>(0,s.jsxs)(s.Fragment,{children:[(0,s.jsxs)(a(),{children:[s.jsx("title",{children:"Compured"}),s.jsx("meta",{name:"description",content:"Descripcion compured"}),s.jsx("meta",{name:"viewport",content:"width=device-width, initial-scale=1"}),s.jsx("link",{rel:"icon",href:"/favicon.ico"})]}),s.jsx(n.Z,{product:e,categs:t,featured:r})]});async function p({params:e}){let t=e.id,r=t.slice(t.indexOf("=")+1,t.indexOf("&")),i=await (0,d.g)(r),s=await (0,l.Q)(),o=await (0,l.V)(129);return{props:{product:i,categories:s,featured:o[0]},revalidate:10}}async function u(){return{paths:[],fallback:"blocking"}}i()}catch(e){i(e)}})},6729:(e,t,r)=>{"use strict";async function i(e){let t=[1,2],r=null;try{let i=t.map(async t=>{let r=await s(e,t);return r}),o=await Promise.all(i),a=o.reduce((e,t)=>t.stockactual?e+Number(t.stockactual):e+0,0),n=o.map((e,r)=>({stock:e.stockactual?Number(e.stockactual):0,sucursal:t[r]}));r={...o[0],stockactual:a,productsStock:n}}catch(e){console.error("Error:",e.message)}return r}async function s(e,t){try{let r=await fetch(`https://api-alfa.saasargentina.com/v0.2/productos/${e}?iue=PuaNYqpDhRBJ7K80I8WC&iddeposito=${t}`);if(!r.ok)throw Error(`Error en la solicitud: ${r.statusText}`);let i=await r.json();return i.resultados}catch(e){throw console.error("Error:",e.message),e}}r.d(t,{g:()=>i})},5861:(e,t,r)=>{"use strict";async function i(e){let t=[1,2],r=[];for(let i=0;i<t.length;i++)r.push(await s(t[i],e));let i=new Set(r.map(e=>e.idproducto));return r=[...i].map(e=>r.find(t=>t.idproducto===e))}async function s(e,t){try{let r=await fetch(`https://api-beta.saasargentina.com/v1/productos?busqueda=&datosextras=&desde=0&cantidad=100&iddeposito=${e}&mostrarimagenes=1&idrubro=${t}&orden=nombre&iue=PuaNYqpDhRBJ7K80I8WC&S=epqr6c893g5khekkir9s0l6k6n&_=1700488253028`);if(!r.ok)throw Error(`Error en la solicitud: ${r.statusText}`);let i=await r.json();return i.resultados}catch(e){console.error(`Error en cargarProductos: ${e.message}`)}}async function o(){try{let e=await fetch("https://api-beta.saasargentina.com/v1/rubros?idrubro=0&desde=0&cantidad=100&orden=nombre&iue=PuaNYqpDhRBJ7K80I8WC&S=epqr6c893g5khekkir9s0l6k6n&_=1700488253028");if(!e.ok)throw Error(`Error en la solicitud: ${e.statusText}`);let t=await e.json();return t}catch(e){console.error(`Error en cargarProductos: ${e.message}`)}}async function a(e){try{let t=await fetch(`https://api-beta.saasargentina.com/v1/rubros?idrubro=${e}&desde=0&cantidad=100&orden=nombre&iue=PuaNYqpDhRBJ7K80I8WC&S=epqr6c893g5khekkir9s0l6k6n&_=1700488253028`);if(!t.ok)throw Error(`Error en la solicitud: ${t.statusText}`);let r=await t.json(),i=r.map(e=>({idrubro:e.idrubro,nombre:e.nombre}));return i}catch(e){console.error(`Error en cargarProductos: ${e.message}`)}}async function n(){try{let e=await o(),t=[];for(let r of e){let e=await a(r.idrubro);t.push({parent:r,children:[...e]})}return t}catch(e){throw console.error(`Error in getAllCategoriesAndSubCategories: ${e.message}`),e}}r.d(t,{Q:()=>n,V:()=>i})},4700:()=>{},3039:()=>{},5392:()=>{},7644:()=>{},5244:(e,t)=>{"use strict";var r;Object.defineProperty(t,"x",{enumerable:!0,get:function(){return r}}),function(e){e.PAGES="PAGES",e.PAGES_API="PAGES_API",e.APP_PAGE="APP_PAGE",e.APP_ROUTE="APP_ROUTE"}(r||(r={}))},4830:(e,t,r)=>{"use strict";e.exports=r(7093).vendored.contexts.Loadable},5152:(e,t,r)=>{e.exports=r(1342)},2785:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/pages.runtime.prod.js")},968:e=>{"use strict";e.exports=require("next/head")},6689:e=>{"use strict";e.exports=require("react")},6405:e=>{"use strict";e.exports=require("react-dom")},997:e=>{"use strict";e.exports=require("react/jsx-runtime")},7518:e=>{"use strict";e.exports=require("styled-components")},2184:e=>{"use strict";e.exports=import("swiper/modules")},3015:e=>{"use strict";e.exports=import("swiper/react")},7147:e=>{"use strict";e.exports=require("fs")},1017:e=>{"use strict";e.exports=require("path")},2781:e=>{"use strict";e.exports=require("stream")},9796:e=>{"use strict";e.exports=require("zlib")}};var t=require("../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),i=t.X(0,[428,571,859,488],()=>r(2046));module.exports=i})();