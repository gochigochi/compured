(()=>{var e={};e.id=820,e.ids=[820,888,660],e.modules={1323:(e,t)=>{"use strict";Object.defineProperty(t,"l",{enumerable:!0,get:function(){return function e(t,r){return r in t?t[r]:"then"in t&&"function"==typeof t.then?t.then(t=>e(t,r)):"function"==typeof t&&"default"===r?t:void 0}}})},8826:(e,t,r)=>{"use strict";r.r(t),r.d(t,{config:()=>x,default:()=>d,getServerSideProps:()=>p,getStaticPaths:()=>u,getStaticProps:()=>c,reportWebVitals:()=>g,routeModule:()=>v,unstable_getServerProps:()=>b,unstable_getServerSideProps:()=>j,unstable_getStaticParams:()=>m,unstable_getStaticPaths:()=>f,unstable_getStaticProps:()=>h});var i=r(7093),n=r(5244),s=r(1323),o=r(4003),l=r(5401),a=r(6908);let d=(0,s.l)(a,"default"),c=(0,s.l)(a,"getStaticProps"),u=(0,s.l)(a,"getStaticPaths"),p=(0,s.l)(a,"getServerSideProps"),x=(0,s.l)(a,"config"),g=(0,s.l)(a,"reportWebVitals"),h=(0,s.l)(a,"unstable_getStaticProps"),f=(0,s.l)(a,"unstable_getStaticPaths"),m=(0,s.l)(a,"unstable_getStaticParams"),b=(0,s.l)(a,"unstable_getServerProps"),j=(0,s.l)(a,"unstable_getServerSideProps"),v=new i.PagesRouteModule({definition:{kind:n.x.PAGES,page:"/_error",pathname:"/_error",bundlePath:"",filename:""},components:{App:l.default,Document:o.default},userland:a})},6537:(e,t,r)=>{"use strict";r.d(t,{Z:()=>l,u:()=>o});var i=r(997),n=r(6689);let s=(0,n.createContext)(),o=()=>(0,n.useContext)(s),l=({children:e})=>{let[t,r]=(0,n.useState)();return i.jsx(s.Provider,{value:{categories:t,setCategories:r},children:e})}},6908:(e,t,r)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0}),Object.defineProperty(t,"default",{enumerable:!0,get:function(){return Error}});let i=r(167),n=i._(r(6689)),s=i._(r(9201)),o={400:"Bad Request",404:"This page could not be found",405:"Method Not Allowed",500:"Internal Server Error"};function l(e){let{res:t,err:r}=e,i=t&&t.statusCode?t.statusCode:r?r.statusCode:404;return{statusCode:i}}let a={error:{fontFamily:'system-ui,"Segoe UI",Roboto,Helvetica,Arial,sans-serif,"Apple Color Emoji","Segoe UI Emoji"',height:"100vh",textAlign:"center",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center"},desc:{lineHeight:"48px"},h1:{display:"inline-block",margin:"0 20px 0 0",paddingRight:23,fontSize:24,fontWeight:500,verticalAlign:"top"},h2:{fontSize:14,fontWeight:400,lineHeight:"28px"},wrap:{display:"inline-block"}};class Error extends n.default.Component{render(){let{statusCode:e,withDarkMode:t=!0}=this.props,r=this.props.title||o[e]||"An unexpected error has occurred";return n.default.createElement("div",{style:a.error},n.default.createElement(s.default,null,n.default.createElement("title",null,e?e+": "+r:"Application error: a client-side exception has occurred")),n.default.createElement("div",{style:a.desc},n.default.createElement("style",{dangerouslySetInnerHTML:{__html:"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}"+(t?"@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}":"")}}),e?n.default.createElement("h1",{className:"next-error-h1",style:a.h1},e):null,n.default.createElement("div",{style:a.wrap},n.default.createElement("h2",{style:a.h2},this.props.title||e?r:n.default.createElement(n.default.Fragment,null,"Application error: a client-side exception has occurred (see the browser console for more information)"),"."))))}}Error.displayName="ErrorPage",Error.getInitialProps=l,Error.origGetInitialProps=l,("function"==typeof t.default||"object"==typeof t.default&&null!==t.default)&&void 0===t.default.__esModule&&(Object.defineProperty(t.default,"__esModule",{value:!0}),Object.assign(t.default,t),e.exports=t.default)},5401:(e,t,r)=>{"use strict";r.r(t),r.d(t,{default:()=>D});var i=r(997),n=r(2435),s=r.n(n);r(6764);var o=r(6689);let l=()=>(0,i.jsxs)("svg",{xmlns:"http://www.w3.org/2000/svg",width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[i.jsx("circle",{cx:"11",cy:"11",r:"8"}),i.jsx("line",{x1:"21",y1:"21",x2:"16.65",y2:"16.65"})]}),a=()=>(0,i.jsxs)("svg",{xmlns:"http://www.w3.org/2000/svg",width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[i.jsx("line",{x1:"5",y1:"12",x2:"19",y2:"12"}),i.jsx("polyline",{points:"12 5 19 12 12 19"})]}),d=()=>(0,i.jsxs)("svg",{xmlns:"http://www.w3.org/2000/svg",width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[i.jsx("line",{x1:"19",y1:"12",x2:"5",y2:"12"}),i.jsx("polyline",{points:"12 19 5 12 12 5"})]});var c=r(7518),u=r.n(c);let p=u().form` 
    display: flex;
    align-items: center;
`,x=u().input`
    width: 100%;
    height: 35px;
    border-radius: 500px 0 0 500px;
    border: 1px solid #cfd7d9;
    padding: 5px 20px;
    font-size: 1rem;
`,g=u().button`
    cursor: pointer;
    border-radius: 0 500px 500px 0;
    border: 1px solid #cfd7d9;
    border-left: none;
    height: 35px;
    padding: 5px;
    width: 65px;
    display: grid;
    place-items: center;

    svg {
        font-size: 1.4rem;
    }
`,h=async e=>{let t=await fetch("https://api-beta.saasargentina.com/v1/productos?callback=productoscallback&busqueda=Auriculares&datosextras=&desde=0&cantidad=100&mostrarimagenes=1&idrubro=0&orden=nombre");console.log(t);let r=await t.json();console.log(r)},f=()=>{let e=(0,o.useRef)();return(0,i.jsxs)(p,{onSubmit:t=>{if(t.preventDefault(),e.current&&e?.current?.length!==0){let t=e.current.toLowerCase().trim().normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/[^a-zA-Z0-9 ]/g,"").replace(/\s+/g,"-");h(t)}},children:[i.jsx(x,{type:"text",name:"term",onChange:t=>e.current=t.target.value}),i.jsx(g,{type:"submit",children:i.jsx(l,{})})]})};var m=r(1163),b=r(6537);let j=e=>e.toLowerCase().replace(/[^a-z0-9 -]/g,"").replace(/\s+/g,"-").replace(/-+/g,"-").trim();var v=r(1664),y=r.n(v);let w=u().div`
    position: relative;
`,P=u().button`
    cursor: pointer;
`,S=u().div`
    position: absolute;
    top: 50px;
    padding: 25px;
    background-color: #fff;
    display: grid;
    width: 100vw;
    max-width: 400px;
    max-height: 80vh;
    overflow-y: scroll;
    box-shadow: var(--light-shadow);
    border-radius: 12px;
`,k=u().button`
    padding: 25px;
    cursor: pointer;
    border-radius: 8px;
    display: flex;
    align-items: center;
    position: relative;

    &:hover {
        background-color: #ededed;

        i {
            right: 25px;
            opacity: 1;
        }
    }
`,_=u().i`
    position: absolute;
    right: 30px;
    transition: all .2s ease-in-out;
    opacity: 0;

    svg {
        font-size: 5px;
    }
`,E=u().div`
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0 25px 25px 20px;
`,A=u().button`
    padding: 25px;
    cursor: pointer;
    border-radius: 8px;
    display: flex;
    align-items: center;
    position: relative;

    &:hover {
        background-color: #ededed;

        i {
            right: 25px;
            opacity: 1;
        }
    }
`,C=u().button`
    cursor: pointer;
`,q=u().button`
    width: 20px;
    height: auto;
    display: grid;
    place-items: center;
    cursor: pointer;

    svg {
        pointer-events: none;
    }
`,L=({children:e})=>{let t=(0,m.useRouter)(),{categories:r}=(0,b.u)(),[n,s]=(0,o.useState)(!1),[l,c]=(0,o.useState)({name:"",id:"",items:[]});(0,o.useEffect)(()=>{let e=e=>{"container"!==e.target.id&&"flyout-btn"!==e.target.id&&(s(!n),c([]))};return n&&window.addEventListener("click",e),n||window.removeEventListener("click",e),()=>window.removeEventListener("click",e)},[n]);let u=(e,r)=>{let i=j(e);t.push(`/productos/${r}`,`/productos/id=${r}&${i}`)};return(0,i.jsxs)(w,{children:[i.jsx(P,{id:"flyout-btn",onClick:()=>s(!n),children:e}),n?i.jsx(S,{id:"container",children:l?.items?.length>0?i.jsx(()=>(0,i.jsxs)(i.Fragment,{children:[(0,i.jsxs)(E,{children:[i.jsx(q,{id:"flyout-btn",onClick:()=>c({name:"",id:"",items:[]}),children:i.jsx(d,{})}),i.jsx(C,{onClick:()=>u(l.name,l.id),children:"Ver todo"})]}),l?.items.map(e=>i.jsxs(A,{onClick:()=>u(e.nombre,e.idrubro),id:"flyout-btn",children:[e.nombre,i.jsx(_,{children:i.jsx(a,{})})]},e.idrubro))]}),{}):i.jsx(()=>i.jsx(i.Fragment,{children:r?.map(e=>i.jsxs(k,{onClick:()=>c({name:e.parent.nombre,id:e.parent.idrubro,items:e.children}),id:"flyout-btn",children:[e.parent.nombre,i.jsx(_,{children:i.jsx(a,{})})]},e.parent.idrubro))}),{})}):null]})},I=u().nav`
    position: relative;
    top: 2px;
    margin-left: 100px;
    display: flex;
    gap: 25px;
    align-items: center;
`,z=u()(y())`
    font-weight: 500;
`,G=()=>(0,i.jsxs)(I,{children:[i.jsx(L,{children:"Categor\xedas"}),i.jsx(z,{href:"/",children:"Servicios"}),i.jsx(z,{href:"/",children:"Contacto"})]});var M=r(5675),O=r.n(M);let R=u().header`
    position: relative;
    box-shadow: 0px 5px 11px 0px rgba(25, 141, 179, 0.1);
    z-index: 800;
`,F=u().div`
    max-width: 1500px;
    margin: 0 auto;
    padding: 0 12px;
    display: flex;
    justify-content: space-between;
    display: grid;
    grid-template-columns: minmax(100px, 150px) 1fr minmax(250px, 500px);
`,N=u()(y())`
    position: relative;
    height: 70px;
`,W=u()(O())`
    object-fit: contain;
`,H=()=>i.jsx(R,{children:(0,i.jsxs)(F,{children:[i.jsx(N,{href:"/",children:i.jsx(W,{src:"/assets/logo.png",alt:"logo compured",fill:!0,priority:!0})}),i.jsx(G,{}),i.jsx(f,{})]})}),B=({children:e})=>(0,i.jsxs)(i.Fragment,{children:[i.jsx(H,{}),i.jsx("main",{children:e})]});function D({Component:e,pageProps:t}){return i.jsx(b.Z,{children:i.jsx(B,{className:s().className,children:i.jsx(e,{...t})})})}},4003:(e,t,r)=>{"use strict";r.r(t),r.d(t,{default:()=>l});var i=r(997),n=r(6859),s=r.n(n),o=r(7518);class l extends s(){static async getInitialProps(e){let t=new o.ServerStyleSheet,r=e.renderPage;try{e.renderPage=()=>r({enhanceApp:e=>r=>t.collectStyles(i.jsx(e,{...r}))});let n=await s().getInitialProps(e);return{...n,styles:(0,i.jsxs)(i.Fragment,{children:[n.styles,t.getStyleElement()]})}}finally{t.seal()}}render(){return(0,i.jsxs)(n.Html,{lang:"en",children:[i.jsx(n.Head,{}),(0,i.jsxs)("body",{children:[i.jsx(n.Main,{}),i.jsx(n.NextScript,{})]})]})}}},6764:()=>{},5244:(e,t)=>{"use strict";var r;Object.defineProperty(t,"x",{enumerable:!0,get:function(){return r}}),function(e){e.PAGES="PAGES",e.PAGES_API="PAGES_API",e.APP_PAGE="APP_PAGE",e.APP_ROUTE="APP_ROUTE"}(r||(r={}))},2785:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/pages.runtime.prod.js")},6689:e=>{"use strict";e.exports=require("react")},6405:e=>{"use strict";e.exports=require("react-dom")},997:e=>{"use strict";e.exports=require("react/jsx-runtime")},7518:e=>{"use strict";e.exports=require("styled-components")},7147:e=>{"use strict";e.exports=require("fs")},1017:e=>{"use strict";e.exports=require("path")},2781:e=>{"use strict";e.exports=require("stream")},9796:e=>{"use strict";e.exports=require("zlib")}};var t=require("../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),i=t.X(0,[428,571,859],()=>r(8826));module.exports=i})();