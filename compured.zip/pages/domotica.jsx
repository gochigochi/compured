import Domotica from '@/components/domotica/Domotica'
import React from 'react'

const DomoticaPage = () => <Domotica />

export default DomoticaPage