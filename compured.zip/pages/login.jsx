import Login from '@/components/admin/login/Login'

const LoginPage = () => <Login />

export default LoginPage