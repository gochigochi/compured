import { Element } from './Elements'

const ButtonLoader = () => <Element />

export default ButtonLoader