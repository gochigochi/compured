import styled from "styled-components"

export const SelectorEl = styled.select`
    border: none;
    outline: none;
    font-size: 1rem;
    margin-left: 15px;
    cursor: pointer;
`